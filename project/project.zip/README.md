# PriceFinder PRO Android

Native Android client for PriceFinder PRO v18.

## Requirements
- Android Studio 2026.1.x or newer.
- Android SDK Platform 36 + Build Tools 36.0.0.
- JDK 17.
- PriceFinder PRO v18 backend reachable by HTTPS (or HTTP only for local development).

## Build
Open the project in Android Studio and build `app > build`.
APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Configure
The app opens a Settings sheet where you enter:
- Backend URL, e.g. `https://price.example.com`
- API Key matching the server's `X-API-Key` / configured API key.

For an emulator talking to a local backend, use `http://10.0.2.2:8000` and enable local cleartext in the app only during development.

## API
The app calls:
`GET /api/v18/market-search?q=<query>`
with the `X-API-Key` header.

The UI renders:
- platform ranking (gold/silver/bronze)
- seller/offer ranking
- all priced offers ordered low to high
- exact-SKU status
- discovery coverage and source errors

This client never scrapes marketplaces directly; scraping, resilience and verification remain on the backend.
