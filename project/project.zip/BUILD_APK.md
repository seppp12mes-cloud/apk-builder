# ساخت APK

این پروژه آمادهٔ build است.

## Android Studio
پروژه را در Android Studio باز کن. SDK Platform 36 و Build Tools 36.0.0 را نصب/انتخاب کن، سپس Build > Build APK(s) را بزن.

## Command line
با JDK 17 و Gradle 9.6.0:

```bash
gradle :app:assembleDebug
```

خروجی:
`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
Workflow موجود در `.github/workflows/android.yml` به‌صورت دستی یا با تغییرات کد، APK debug را به‌عنوان Artifact می‌سازد.

## Backend
در اولین اجرای برنامه، Settings را باز کن و آدرس Backend v18 و API Key را وارد کن.
مثال production:
`https://price.example.com`

این اپ مستقیماً سایت‌های فروشگاهی را scrape نمی‌کند؛ تمام Search Intelligence، Marketplace discovery، Exact-SKU verification و resilience روی backend v18 باقی می‌ماند.
