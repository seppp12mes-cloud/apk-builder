#!/usr/bin/env bash
set -euo pipefail
if command -v gradle >/dev/null 2>&1; then
  gradle :app:assembleDebug
else
  echo "Gradle not found. Open in Android Studio or install Gradle 9.6.0."
  exit 1
fi
