# قوانین اختصاصی ProGuard/R8 را در صورت نیاز اینجا اضافه کنید.
# این پروژه پیش‌فرض از proguard-android-optimize.txt هم استفاده می‌کند.
