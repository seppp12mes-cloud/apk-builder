# PriceFinder PRO currently uses platform APIs only; keep this file for future R8 rules.
