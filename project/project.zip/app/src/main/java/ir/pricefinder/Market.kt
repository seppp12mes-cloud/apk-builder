package ir.pricefinder

import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * تنها منبع حقیقت قیمت‌های لحظه‌ای (طلا/ارز/رمزارز/صرافی‌ها).
 * - یک‌بار برای کل برنامه اجرا می‌شود، پس صفحه‌ی خانه و تب قیمت‌ها همیشه هم‌زمان‌اند.
 * - فقط وقتی برنامه جلوی چشم است درخواست می‌زند؛ با برگشتن به برنامه فوراً تازه می‌شود.
 * - kick() (کشیدن صفحه به پایین) همه‌ی حلقه‌ها را همان لحظه بیدار می‌کند.
 */
object Mkt {
    val secs = mutableStateMapOf<Int, Section>()      // 0 ایران، 1 رمزارز، 2 جهانی
    val failed = mutableStateMapOf<Int, Boolean>()
    val ex = mutableStateMapOf<String, Map<String, Tick>>()
    val exAt = mutableStateMapOf<String, Long>()
    val exBad = mutableStateMapOf<String, Boolean>()
    val exDir = mutableStateMapOf<String, Int>()
    var refreshing by mutableStateOf(false)

    private val tick = MutableStateFlow(0)
    val fg = MutableStateFlow(true)
    private val exOn = MutableStateFlow(false)
    private val tried = HashMap<Int, Long>()          // زمان شروعِ آخرین تلاشِ تمام‌شده‌ی هر منبع (برای دانستن پایان رفرش)
    private val hist = HashMap<String, MutableList<Double>>()

    private class ExSrc(val name: String, val f: suspend () -> Map<String, Tick>)
    private val exSrcs = listOf(ExSrc("بیت‌پین") { Api.exBitpin() }, ExSrc("رمزینکس") { Api.exRamzinex() }, ExSrc("نوبیتکس") { Api.exNobitex() })
    val exNames get() = exSrcs.map { it.name }

    fun kick() { tick.update { it + 1 } }
    fun setForeground(b: Boolean) { fg.value = b; if (b) kick() }
    fun setExchangesVisible(b: Boolean) { exOn.value = b; if (b) kick() }

    private suspend fun <T> attempt(ms: Long, f: suspend () -> T?): T? = try {
        withTimeoutOrNull(ms) { f() }
    } catch (e: CancellationException) { throw e } catch (e: Exception) {
        currentCoroutineContext().ensureActive(); null
    }

    private suspend fun waitUntilOn(needEx: Boolean) {
        if (fg.value && (!needEx || exOn.value)) return
        combine(fg, exOn) { f, e -> f && (!needEx || e) }.first { it }
    }

    private suspend fun loop(every: Long, needEx: Boolean = false, body: suspend () -> Unit) {
        while (true) {
            waitUntilOn(needEx)
            val seen = tick.value
            val t0 = System.currentTimeMillis()
            body()
            val rest = every - (System.currentTimeMillis() - t0)
            if (rest > 0) withTimeoutOrNull(rest) { tick.first { it != seen } }
        }
    }

    private fun put(i: Int, s: Section?) {
        if (s == null) { failed[i] = true; return }
        failed[i] = false
        secs[i] = s.copy(items = s.items.map { q ->
            if (q.spark.size < 2 && q.num > 0) {
                val h = hist.getOrPut(q.id) { mutableListOf() }; h += q.num; if (h.size > 80) h.removeAt(0); q.copy(spark = h.toList())
            } else q
        })
    }

    private suspend fun section(i: Int, every: Long, ms: Long, f: suspend () -> Section?) =
        loop(every) { val st = System.currentTimeMillis(); put(i, attempt(ms) { f() }); tried[i] = st }

    /** در LaunchedEffect برنامه صدا زده می‌شود و با بسته‌شدن برنامه لغو می‌شود */
    suspend fun run() = coroutineScope {
        launch { section(0, 10_000, 11_000) { Api.iranSection() } }
        launch { section(1, 10_000, 12_000) { Api.cryptoSection() } }
        launch { section(2, 20_000, 10_000) { Api.worldSection() } }
        exSrcs.forEachIndexed { idx, s ->
            launch {
                loop(5_000, needEx = true) {
                    val st = System.currentTimeMillis()
                    val r = attempt(4_500) { s.f() }
                    if (!r.isNullOrEmpty()) {
                        val old = ex[s.name]
                        r.forEach { (c, t) -> val p = old?.get(c)?.price; if (p != null && p != t.price) exDir[s.name + c] = if (t.price > p) 1 else -1 }
                        ex[s.name] = r; exAt[s.name] = System.currentTimeMillis(); exBad[s.name] = false
                    } else exBad[s.name] = true
                    tried[10 + idx] = st
                }
            }
        }
    }

    /** کشیدن صفحه به پایین: همه‌چیز همین الان دوباره گرفته می‌شود و تا پایان (حداکثر ۱۲ ثانیه) نشانگر می‌ماند */
    suspend fun refreshNow() {
        if (refreshing) return
        val t0 = System.currentTimeMillis()
        refreshing = true
        try {
            kick()
            delay(600)
            withTimeoutOrNull(12_000) {
                while (true) {
                    val core = (0..2).all { (tried[it] ?: 0L) >= t0 }
                    val exs = !exOn.value || exSrcs.indices.all { (tried[10 + it] ?: 0L) >= t0 }
                    if (core && exs) break
                    delay(150)
                }
            }
            delay(300)
        } finally { refreshing = false }
    }
}
