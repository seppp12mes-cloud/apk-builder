package ir.pricefinder

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.net.URLEncoder

/** همه‌ی کارهای مربوط به لینک: تمیزکردن، لینک جایگزین و بازکردن مطمئن (هیچ‌وقت بی‌صدا شکست نمی‌خورد) */
object Links {
    private fun base(source: String) = when (source) {
        "ترب", "ترب (حضوری)" -> "https://torob.com"
        "دیجی‌کالا" -> "https://www.digikala.com"
        "باسلام" -> "https://basalam.com"
        else -> ""
    }

    fun torobPage(key: String) = "https://torob.com/p/$key/"
    fun torobSearch(title: String) = "https://torob.com/search/?query=" + URLEncoder.encode(title.take(80), "UTF-8")

    /** هر شکلی از آدرس (نسبی، بدون https، خالی، "null") را به آدرس کامل تبدیل می‌کند؛ اگر ممکن نبود رشته‌ی خالی */
    fun clean(raw: String?, source: String = ""): String {
        var u = raw?.trim().orEmpty().replace(" ", "%20")
        if (u.isEmpty() || u.equals("null", true) || u == "#") return ""
        u = when {
            u.startsWith("https://", true) || u.startsWith("http://", true) -> u
            u.startsWith("//") -> "https:$u"
            u.startsWith("/v4/") -> "https://api.torob.com$u"
            u.startsWith("/") -> { val b = base(source); if (b.isEmpty()) return ""; b + u }
            u.contains(".") && !u.contains(" ") -> "https://$u"
            else -> return ""
        }
        return if (u.length > 10 && Uri.parse(u).host?.contains(".") == true) u else ""
    }

    /** ترتیب تلاش برای بازکردن: لینک خود پیشنهاد ← صفحه‌ی محصول در ترب ← جستجوی عنوان در ترب */
    fun candidates(o: Offer): List<String> = buildList {
        clean(o.url, o.source).takeIf { it.isNotEmpty() }?.let { add(it) }
        if (o.key.isNotBlank()) add(torobPage(o.key))
        if (o.title.isNotBlank()) add(torobSearch(o.title))
    }.distinct()

    private fun launch(ctx: Context, url: String): Boolean = try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE))
        true
    } catch (e: Exception) { false }

    fun openUrl(ctx: Context, url: String) {
        if (url.isNotEmpty() && launch(ctx, url)) return
        toast(ctx, "مرورگری برای باز کردن لینک پیدا نشد")
    }

    fun open(ctx: Context, o: Offer) {
        val list = candidates(o)
        for (u in list) if (launch(ctx, u)) return
        list.firstOrNull()?.let {
            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager)?.setPrimaryClip(ClipData.newPlainText("link", it))
            toast(ctx, "باز نشد؛ لینک کپی شد")
        } ?: toast(ctx, "لینکی برای این پیشنهاد موجود نیست")
    }

    fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
}
