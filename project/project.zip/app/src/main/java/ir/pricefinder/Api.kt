package ir.pricefinder

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

data class Offer(val title: String, val priceToman: Long, val source: String, val url: String, val shop: String = "")
data class Quote(val name: String, val value: String, val change: Double?)
data class Section(val title: String, val items: List<Quote>)

/** همه‌ی آدرس‌ها اینجاست؛ اگر سایتی API را عوض کرد فقط همین فایل را اصلاح کنید. */
object Api {
    private val client = OkHttpClient()

    private suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .header("Accept", "application/json").build()
        client.newCall(req).execute().use {
            if (!it.isSuccessful) error("HTTP ${it.code}")
            it.body!!.string()
        }
    }

    private suspend fun post(url: String, json: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .header("Accept", "application/json")
            .post(json.toRequestBody("application/json".toMediaType())).build()
        client.newCall(req).execute().use {
            if (!it.isSuccessful) error("HTTP ${it.code}")
            it.body!!.string()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    // ---------- جستجوی قیمت ----------
    private suspend fun digikala(q: String): List<Offer> {
        val arr = JSONObject(get("https://api.digikala.com/v1/search/?q=${enc(q)}"))
            .getJSONObject("data").getJSONArray("products")
        val out = mutableListOf<Offer>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val rial = p.optJSONObject("default_variant")?.optJSONObject("price")?.optLong("selling_price", 0) ?: 0
            if (rial <= 0) continue
            out += Offer(p.optString("title_fa"), rial / 10, "دیجی‌کالا",
                "https://www.digikala.com/product/dkp-${p.optInt("id")}/")
        }
        return out
    }

    private suspend fun torob(q: String): List<Offer> {
        val arr = JSONObject(get("https://api.torob.com/v4/base-product/search/?page=0&sort=popularity&size=24&query=${enc(q)}&q=${enc(q)}&source=next"))
            .optJSONArray("results") ?: return emptyList()
        val out = mutableListOf<Offer>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val price = p.optLong("price", 0)
            if (price <= 0) continue
            out += Offer(p.optString("name1"), price, "ترب", p.optString("web_client_absolute_url"), p.optString("shop_text"))
        }
        return out
    }

    // باسلام: جستجوی عمومی (POST/JSON). اگر آدرس یا ساختار پاسخ عوض شد فقط همین تابع را اصلاح کنید.
    private const val BASALAM_URL = "https://search.basalam.com/ai-engine/api/v2.0/product/search"

    private suspend fun basalam(q: String): List<Offer> {
        val body = JSONObject().put("q", q).put("rows", 24).put("start", 0).put("filters", JSONObject()).toString()
        val j = JSONObject(post(BASALAM_URL, body))
        val arr = j.optJSONArray("products") ?: j.optJSONObject("data")?.optJSONArray("products") ?: return emptyList()
        val out = mutableListOf<Offer>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val price = p.optLong("price", 0).takeIf { it > 0 } ?: p.optLong("primaryPrice", 0)
            val id = p.optLong("id", 0)
            if (price <= 0 || id <= 0) continue
            val title = p.optString("name").ifBlank { p.optString("title") }
            val shop = p.optJSONObject("vendor")?.optString("name").orEmpty()
            out += Offer(title, price, "باسلام", "https://basalam.com/p/$id", shop)
        }
        return out
    }

    /** نتیجه: لیست مرتب از ارزان به گران + نام منابعی که جواب ندادند */
    suspend fun search(q: String): Pair<List<Offer>, List<String>> = coroutineScope {
        val sources = listOf<Pair<String, suspend (String) -> List<Offer>>>(
            "دیجی‌کالا" to ::digikala, "ترب" to ::torob, "باسلام" to ::basalam
        )
        val jobs = sources.map { (name, f) -> name to async { runCatching { f(q) } } }
        val all = mutableListOf<Offer>(); val failed = mutableListOf<String>()
        for ((name, job) in jobs) {
            val r = job.await()
            r.onSuccess { all += it }.onFailure { failed += name }
        }
        // اگر قیمت‌های باسلام حدود ۱۰ برابر بقیه بود (ریال به‌جای تومان)، خودکار اصلاح می‌شود
        val others = all.filter { it.source != "باسلام" }.map { it.priceToman }.sorted()
        val bas = all.filter { it.source == "باسلام" }.map { it.priceToman }.sorted()
        val rial = others.size >= 3 && bas.size >= 3 && others[others.size / 2] > 0 &&
            bas[bas.size / 2] / others[others.size / 2] >= 6
        all.map { if (rial && it.source == "باسلام") it.copy(priceToman = it.priceToman / 10) else it }
            .sortedBy { it.priceToman } to failed
    }

    // ---------- قیمت‌های لحظه‌ای ----------
    private fun fmt(v: Double, dec: Int = 0) = String.format(Locale.US, "%,.${dec}f", v)

    private suspend fun tgju(): List<Quote> {
        val cur = JSONObject(get("https://call4.tgju.org/ajax.json")).getJSONObject("current")
        val keys = listOf(
            "price_dollar_rl" to "دلار آزاد", "price_eur" to "یورو",
            "geram18" to "طلای ۱۸ عیار (گرم)", "geram24" to "طلای ۲۴ عیار (گرم)",
            "sekee" to "سکه امامی", "silver" to "نقره"
        )
        return keys.mapNotNull { (k, name) ->
            val o = cur.optJSONObject(k) ?: return@mapNotNull null
            val toman = o.optString("p").replace(",", "").toDoubleOrNull()?.div(10) ?: return@mapNotNull null
            val dp = o.optString("dp").toDoubleOrNull()
            Quote(name, fmt(toman) + " تومان", dp?.let { if (o.optString("dt") == "low") -it else it })
        }
    }

    private suspend fun yahoo(sym: String, name: String, unit: String): Quote? = runCatching {
        val meta = JSONObject(get("https://query1.finance.yahoo.com/v8/finance/chart/$sym?interval=1d&range=1d"))
            .getJSONObject("chart").getJSONArray("result").getJSONObject(0).getJSONObject("meta")
        val p = meta.getDouble("regularMarketPrice")
        val prev = meta.optDouble("chartPreviousClose", Double.NaN)
        Quote(name, fmt(p, 2) + " $unit", if (prev.isNaN() || prev == 0.0) null else (p - prev) / prev * 100)
    }.getOrNull()

    private suspend fun crypto(): List<Quote> {
        val arr = org.json.JSONArray(get("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=15&page=1"))
        return (0 until arr.length()).map {
            val c = arr.getJSONObject(it)
            val price = c.getDouble("current_price")
            Quote("${c.getString("name")} (${c.getString("symbol").uppercase()})",
                "$" + fmt(price, if (price < 1) 4 else 2),
                if (c.isNull("price_change_percentage_24h")) null else c.getDouble("price_change_percentage_24h"))
        }
    }

    suspend fun prices(): List<Section> = coroutineScope {
        val iran = async { runCatching { tgju() }.getOrDefault(emptyList()) }
        val world = async {
            listOfNotNull(
                yahoo("GC=F", "اونس طلا", "$"), yahoo("SI=F", "اونس نقره", "$"),
                yahoo("BZ=F", "نفت برنت", "$"), yahoo("CL=F", "نفت WTI", "$")
            )
        }
        val coins = async { runCatching { crypto() }.getOrDefault(emptyList()) }
        listOf(
            Section("طلا، سکه و ارز (بازار ایران)", iran.await()),
            Section("بازار جهانی: طلا، نقره، نفت", world.await()),
            Section("۱۵ ارز دیجیتال برتر", coins.await())
        ).filter { it.items.isNotEmpty() }
    }
}
