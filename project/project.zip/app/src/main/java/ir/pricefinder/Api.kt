package ir.pricefinder

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit

data class Offer(
    val title: String, val priceToman: Long, val source: String, val url: String, val shop: String = "",
    val image: String = "", val key: String = "", val offline: Boolean = false, val city: String = "", val score: Double = 0.0, val old: Long = 0
)
data class Quote(val name: String, val value: String, val change: Double?, val icon: String = "", val logo: String = "",
                 val spark: List<Double> = emptyList(), val id: String = name, val num: Double = 0.0)
data class Section(val title: String, val items: List<Quote>)
data class HomeSec(val order: Int, val title: String, val items: List<Offer>, val big: Boolean = false, val q: String = "")
private class Src(val name: String, val run: suspend () -> List<Offer>)

fun norm(s: String) = s.lowercase().map { when (it) { in '۰'..'۹' -> '0' + (it - '۰'); in '٠'..'٩' -> '0' + (it - '٠'); 'ي' -> 'ی'; 'ك' -> 'ک'; else -> it } }.joinToString("")
/** شباهت دو عنوان (۰ تا ۱) بر اساس کلمات مشترک */
fun sim(a: String, b: String): Double {
    val x = norm(a).split(" ", "‌", "-", "|").filter { it.length >= 2 }.toSet()
    val y = norm(b).split(" ", "‌", "-", "|").filter { it.length >= 2 }.toSet()
    if (x.isEmpty() || y.isEmpty()) return 0.0
    return x.intersect(y).size.toDouble() / minOf(x.size, y.size)
}

/** همه‌ی آدرس‌ها اینجاست؛ اگر سایتی API را عوض کرد فقط همین فایل را اصلاح کنید. */
object Api {
    private val client = OkHttpClient.Builder().callTimeout(9, TimeUnit.SECONDS).build()
    private const val UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"

    private suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).header("User-Agent", UA).header("Accept", "application/json").build()
        client.newCall(req).execute().use {
            if (!it.isSuccessful) error("HTTP ${it.code}")
            it.body!!.string()
        }
    }

    private suspend fun post(url: String, json: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).header("User-Agent", UA).header("Accept", "application/json")
            .post(json.toRequestBody("application/json".toMediaType())).build()
        client.newCall(req).execute().use {
            if (!it.isSuccessful) error("HTTP ${it.code}")
            it.body!!.string()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    // ---------- جستجوی قیمت ----------
    private fun parseDigikala(arr: JSONArray): List<Offer> {
        val out = mutableListOf<Offer>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val pr = p.optJSONObject("default_variant")?.optJSONObject("price")
            val rial = pr?.optLong("selling_price", 0) ?: 0
            if (rial <= 0) continue
            val rrp = pr?.optLong("rrp_price", 0) ?: 0
            val img = p.optJSONObject("images")?.optJSONObject("main")?.optJSONArray("url")?.optString(0).orEmpty()
            out += Offer(p.optString("title_fa"), rial / 10, "دیجی‌کالا", "https://www.digikala.com/product/dkp-${p.optInt("id")}/",
                image = img, old = if (rrp > rial) rrp / 10 else 0)
        }
        return out
    }

    private suspend fun digikala(q: String): List<Offer> =
        parseDigikala(JSONObject(get("https://api.digikala.com/v1/search/?q=${enc(q)}")).getJSONObject("data").getJSONArray("products"))

    /** صفحه‌ی «شگفت‌انگیزها»ی دیجی‌کالا */
    private suspend fun incredible(): List<Offer> =
        parseDigikala(JSONObject(get("https://api.digikala.com/v1/incredible-offers/products/?page=1")).getJSONObject("data").getJSONArray("products"))

    private suspend fun torob(q: String): List<Offer> {
        val arr = JSONObject(get("https://api.torob.com/v4/base-product/search/?page=0&sort=popularity&size=24&query=${enc(q)}&q=${enc(q)}&source=next"))
            .optJSONArray("results") ?: return emptyList()
        val out = mutableListOf<Offer>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val price = p.optLong("price", 0)
            if (price <= 0) continue
            out += Offer(p.optString("name1"), price, "ترب", p.optString("web_client_absolute_url"), p.optString("shop_text"),
                image = p.optString("image_url"), key = p.optString("random_key"))
        }
        return out
    }

    /** فروشندگان یک محصول ترب (ده‌ها فروشگاه). نام فیلدها در پاسخ ترب را اینجا اصلاح کنید. */
    private fun isOffline(p: JSONObject): Boolean {
        val t = (p.optString("shop_type") + " " + p.optString("seller_type")).lowercase()
        return p.optBoolean("is_offline") || p.optBoolean("offline") || p.optBoolean("is_physical") ||
            p.optBoolean("has_physical_store") || "offline" in t || "physical" in t || "حضوری" in t
    }

    suspend fun sellers(key: String): List<Offer> {
        val j = JSONObject(get("https://api.torob.com/v4/base-product/sellers/?prk=${enc(key)}&sort=price&size=40&page=0"))
        val arr = j.optJSONArray("results") ?: j.optJSONObject("products_info")?.optJSONArray("result") ?: return emptyList()
        val out = mutableListOf<Offer>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val price = p.optLong("price", 0)
            if (price <= 0) continue
            val url = p.optString("page_url").ifBlank { p.optString("web_client_absolute_url") }
            if (url.isBlank()) continue
            out += Offer(p.optString("name1"), price, "ترب", url, p.optString("shop_name").ifBlank { p.optString("shop_text") },
                city = p.optString("shop_city").ifBlank { p.optString("city") }, offline = isOffline(p), score = p.optDouble("score", 0.0))
        }
        return out
    }

    /** محصولات مرتبط ترب (بدون لوازم جانبی و نتایج نامرتبط) که فروشندگانشان را می‌خوانیم */
    private suspend fun relevantBases(q: String, n: Int): List<Offer> {
        val all = torob(q).filter { it.key.isNotBlank() }
        if (all.isEmpty()) return all
        val med = all.map { it.priceToman }.sorted()[all.size / 2]
        val tokens = norm(q).split(" ", "\u200c").filter { it.length >= 2 }
        val byPrice = all.filter { it.priceToman >= med * 0.35 }
        val rel = byPrice.filter { b -> val t = norm(b.title); tokens.all { it in t } }
        return (if (rel.isNotEmpty()) rel else byPrice).take(n)
    }

    /** برای هر محصول، ارزان‌ترین پیشنهاد هر فروشگاهِ معتبر (امتیاز پایین حذف می‌شود؛ مقیاس score را اگر لازم بود تغییر دهید) */
    private suspend fun torobShops(q: String): List<Offer> = coroutineScope {
        val bases = relevantBases(q, 3)
        val per = bases.map { base ->
            async {
                runCatching { sellers(base.key) }.map { l ->
                    l.filter { it.score == 0.0 || it.score >= 3.5 }.map { it.copy(title = base.title, image = base.image, key = base.key) }
                        .groupBy { it.shop }.map { e -> e.value.minBy { it.priceToman } }.sortedBy { it.priceToman }.take(15)
                }
            }
        }.awaitAll()
        if (bases.isNotEmpty() && per.all { it.isFailure }) error("فروشندگان دریافت نشد")
        per.flatMap { it.getOrDefault(emptyList()) }
    }

    /** خرید حضوری: فقط فروشندگان حضوری همین محصولات ترب */
    private suspend fun torobOffline(q: String): List<Offer> = coroutineScope {
        relevantBases(q, 5).map { base ->
            async {
                runCatching { sellers(base.key) }.getOrDefault(emptyList()).filter { it.offline }
                    .map { it.copy(title = base.title, image = base.image, key = base.key) }
            }
        }.awaitAll().flatten()
    }

    // باسلام: جستجوی عمومی (POST/JSON). اگر آدرس یا ساختار پاسخ عوض شد فقط همین تابع را اصلاح کنید.
    private const val BASALAM_URL = "https://search.basalam.com/ai-engine/api/v2.0/product/search"

    private suspend fun basalam(q: String): List<Offer> {
        val body = JSONObject().put("q", q).put("rows", 24).put("start", 0).put("filters", JSONObject()).toString()
        val j = JSONObject(post(BASALAM_URL, body))
        val arr = j.optJSONArray("products") ?: j.optJSONObject("data")?.optJSONArray("products") ?: return emptyList()
        val out = mutableListOf<Offer>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val prim = p.optLong("primaryPrice", 0)
            val price = p.optLong("price", 0).takeIf { it > 0 } ?: prim
            val id = p.optLong("id", 0)
            if (price <= 0 || id <= 0) continue
            val title = p.optString("name").ifBlank { p.optString("title") }
            val shop = p.optJSONObject("vendor")?.optString("name").orEmpty()
            val ph = p.optJSONObject("photo")
            val img = ph?.optString("url").orEmpty().ifBlank { ph?.optJSONObject("MEDIUM")?.optString("url").orEmpty() }
            out += Offer(title, price, "باسلام", "https://basalam.com/p/$id", shop, image = img, old = if (prim > price) prim else 0)
        }
        return out
    }

    // فروشگاه‌های ووکامرسی با API عمومی. فهرست را آزادانه ویرایش کنید؛ سایتی که جواب ندهد خودکار کنار گذاشته می‌شود.
    private val wooShops = listOf<Pair<String, String>>() // مثال: "example.ir" to "نام فروشگاه"

    private suspend fun woo(host: String, label: String, q: String): List<Offer> {
        val arr = JSONArray(get("https://$host/wp-json/wc/store/v1/products?search=${enc(q)}&per_page=12"))
        val out = mutableListOf<Offer>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i); val pr = p.optJSONObject("prices") ?: continue
            var v = pr.optString("price").toDoubleOrNull() ?: continue
            repeat(pr.optInt("currency_minor_unit", 0)) { v /= 10 }
            if (pr.optString("currency_code") == "IRR") v /= 10
            if (v <= 0) continue
            out += Offer(p.optString("name"), v.toLong(), label, p.optString("permalink"),
                image = p.optJSONArray("images")?.optJSONObject(0)?.optString("src").orEmpty())
        }
        return out
    }

    private fun fix(all: List<Offer>): List<Offer> {
        // اگر قیمت‌های باسلام حدود ۱۰ برابر بقیه بود (ریال به‌جای تومان)، خودکار اصلاح می‌شود
        val others = all.filter { it.source != "باسلام" }.map { it.priceToman }.sorted()
        val bas = all.filter { it.source == "باسلام" }.map { it.priceToman }.sorted()
        val rial = others.size >= 3 && bas.size >= 3 && others[others.size / 2] > 0 &&
            bas[bas.size / 2] / others[others.size / 2] >= 6
        return all.map { if (rial && it.source == "باسلام") it.copy(priceToman = it.priceToman / 10, old = it.old / 10) else it }
            .distinctBy { it.url + it.shop }.sortedBy { it.priceToman }
    }

    /** همه‌ی منابع هم‌زمان؛ هر منبع که جواب داد، نتیجه بلافاصله به onUpdate می‌رسد (مرتب از ارزان به گران) */
    suspend fun search(q: String, offline: Boolean, onUpdate: (List<Offer>, List<String>) -> Unit) = coroutineScope {
        val sources: List<Src> = if (offline) listOf(Src("ترب (حضوری)") { torobOffline(q) })
        else listOf(Src("دیجی‌کالا") { digikala(q) }, Src("ترب") { torob(q) }, Src("فروشگاه‌های ترب") { torobShops(q) }, Src("باسلام") { basalam(q) }) +
            wooShops.map { (h, l) -> Src(l) { woo(h, l, q) } }
        val all = mutableListOf<Offer>(); val failed = mutableListOf<String>(); val mu = Mutex()
        sources.map { s ->
            launch {
                val r = runCatching { withTimeout(9000) { s.run() } }
                val snap = mu.withLock {
                    r.onSuccess { all += it }.onFailure { failed += s.name }
                    fix(all) to failed.toList()
                }
                withContext(Dispatchers.Main) { onUpdate(snap.first, snap.second) }
            }
        }
    }

    /** صفحه‌ی محصول: فروشندگان ترب + پیشنهادهای هم‌عنوان از سایر منابع، مرتب از ارزان به گران */
    suspend fun sellersFor(o: Offer, pool: List<Offer>): List<Offer> {
        val t = if (o.key.isNotBlank()) runCatching { sellers(o.key) }.getOrDefault(emptyList())
            .map { it.copy(title = o.title, image = o.image, key = o.key) } else emptyList()
        val others = pool.filter { it.source != "ترب" && !it.offline && sim(it.title, o.title) >= 0.6 }
        return (t + others + o).distinctBy { it.url + it.shop }.sortedBy { it.priceToman }
    }

    // ---------- صفحه‌ی اصلی: بخش‌های تصادفی از چند سایت ----------
    private val topics = listOf("گوشی موبایل", "لپ‌تاپ", "تلویزیون", "هدفون بلوتوث", "ساعت هوشمند", "کنسول بازی", "یخچال", "ماشین لباسشویی",
        "جاروبرقی", "دوربین", "تبلت", "اسپیکر", "کوله پشتی", "کفش ورزشی", "عطر", "مانیتور", "کارت گرافیک", "اسکوتر", "دوچرخه",
        "قهوه‌ساز", "پنکه", "کولر گازی", "پاوربانک", "ماوس گیمینگ", "کیبورد", "اسباب‌بازی", "ساعت مچی", "چای ساز", "اتو بخار", "پلی‌استیشن ۵")
    fun randomTopics(n: Int) = topics.shuffled().take(n)

    private suspend fun from(src: Int, q: String) = when (src) { 0 -> digikala(q); 1 -> torob(q); else -> basalam(q) }

    suspend fun home(onSec: (HomeSec) -> Unit) = coroutineScope {
        val t = topics.shuffled()
        fun sec(order: Int, title: String, q: String = "", big: Boolean = false, f: suspend () -> List<Offer>) = launch {
            val r = runCatching { withTimeout(9000) { f() } }.getOrNull().orEmpty().filter { it.image.isNotBlank() }
            if (r.size >= 2 || (big && r.isNotEmpty())) withContext(Dispatchers.Main) { onSec(HomeSec(order, title, r.take(14), big, q)) }
        }
        sec(0, "🎲 پیشنهاد شانسی", big = true) { from((0..2).random(), t[0]).shuffled().take(1) }
        sec(1, "🔥 شگفت‌انگیزها") {
            runCatching { incredible() }.getOrDefault(emptyList()).ifEmpty {
                listOf(t[1], t[2], t[3]).map { q -> async { runCatching { digikala(q) }.getOrDefault(emptyList()) } }.awaitAll().flatten()
                    .filter { it.old > it.priceToman }.sortedByDescending { (it.old - it.priceToman) * 100 / it.old }
            }
        }
        sec(2, "🛒 از دیجی‌کالا: ${t[4]}", t[4]) { digikala(t[4]) }
        sec(3, "🔵 از ترب: ${t[5]}", t[5]) { torob(t[5]) }
        sec(4, "🟢 از باسلام: ${t[6]}", t[6]) { basalam(t[6]) }
        sec(5, "💸 ارزان‌ترین‌های ${t[7]}", t[7]) {
            val l = (digikala(t[7]) + runCatching { torob(t[7]) }.getOrDefault(emptyList())).sortedBy { it.priceToman }
            val med = l.getOrNull(l.size / 2)?.priceToman ?: 0
            l.filter { it.priceToman >= med * 0.35 }
        }
        sec(6, "🏆 پرطرفدار: ${t[8]}", t[8]) { torob(t[8]) }
        sec(7, "✨ ${t[9]}", t[9]) { digikala(t[9]) }
    }

    // ---------- قیمت‌های لحظه‌ای ----------
    private fun fmt(v: Double, dec: Int = 0) = String.format(Locale.US, "%,.${dec}f", v)
    private fun down(v: List<Double>, n: Int = 40) = if (v.size <= n) v else v.filterIndexed { i, _ -> i % (v.size / n + 1) == 0 }

    private suspend fun tgju(): List<Quote> {
        val cur = JSONObject(get("https://call4.tgju.org/ajax.json")).getJSONObject("current")
        val keys = listOf(
            Triple("price_dollar_rl", "دلار آزاد", "💵"), Triple("price_eur", "یورو", "💶"), Triple("price_gbp", "پوند", "💷"),
            Triple("price_aed", "درهم امارات", "💴"), Triple("price_try", "لیر ترکیه", "💱"),
            Triple("geram18", "طلای ۱۸ عیار (گرم)", "🥇"), Triple("geram24", "طلای ۲۴ عیار (گرم)", "🥇"), Triple("mesghal", "مثقال طلا", "🥇"),
            Triple("sekee", "سکه امامی", "🪙"), Triple("sekeb", "سکه بهار آزادی", "🪙"), Triple("nim", "نیم‌سکه", "🪙"),
            Triple("rob", "ربع‌سکه", "🪙"), Triple("silver", "نقره", "🥈")
        )
        return keys.mapNotNull { (k, name, ic) ->
            val o = cur.optJSONObject(k) ?: return@mapNotNull null
            val toman = o.optString("p").replace(",", "").toDoubleOrNull()?.div(10) ?: return@mapNotNull null
            val dp = o.optString("dp").toDoubleOrNull()
            Quote(name, fmt(toman) + " تومان", dp?.let { if (o.optString("dt") == "low") -it else it }, icon = ic, id = k, num = toman)
        }
    }

    private suspend fun yahoo(sym: String, name: String, unit: String, ic: String): Quote? = runCatching {
        val res = JSONObject(get("https://query1.finance.yahoo.com/v8/finance/chart/$sym?interval=1h&range=5d"))
            .getJSONObject("chart").getJSONArray("result").getJSONObject(0)
        val p = res.getJSONObject("meta").getDouble("regularMarketPrice")
        val cl = res.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0).getJSONArray("close")
        val closes = (0 until cl.length()).mapNotNull { if (cl.isNull(it)) null else cl.getDouble(it) }
        val ref = closes.getOrNull(closes.size - 24)?.takeIf { it != 0.0 }
        Quote(name, fmt(p, 2) + " $unit", ref?.let { (p - it) / it * 100 }, icon = ic, spark = down(closes), id = "w-$sym")
    }.getOrNull()

    private val coins = listOf("btc" to "بیت‌کوین", "eth" to "اتریوم", "usdt" to "تتر", "bnb" to "بایننس‌کوین", "xrp" to "ریپل",
        "sol" to "سولانا", "trx" to "ترون", "doge" to "دوج‌کوین", "ada" to "کاردانو", "ton" to "تون‌کوین", "ltc" to "لایت‌کوین",
        "shib" to "شیبا", "dot" to "پولکادوت", "avax" to "آوالانچ", "link" to "چین‌لینک")
    private fun logo(sym: String) = "https://cdn.jsdelivr.net/gh/spothq/cryptocurrency-icons@master/128/color/$sym.png"
    private fun tm(v: Double) = fmt(v, if (v < 100) 2 else 0) + " تومان"

    /** نوبیتکس (صرافی ایرانی): قیمت آخرین معامله به ریال → تومان */
    private suspend fun nobitex(): List<Quote> {
        val body = JSONObject().put("srcCurrency", coins.joinToString(",") { it.first }).put("dstCurrency", "rls").toString()
        val st = JSONObject(post("https://api.nobitex.ir/market/stats", body)).getJSONObject("stats")
        return coins.mapNotNull { (s, n) ->
            val o = st.optJSONObject("$s-rls") ?: return@mapNotNull null
            val last = o.optString("latest").toDoubleOrNull()?.div(10) ?: return@mapNotNull null
            Quote("$n (${s.uppercase()})", tm(last), o.optString("dayChange").toDoubleOrNull(), logo = logo(s), id = "c-$s", num = last)
        }
    }

    /** والکس (صرافی ایرانی) — جایگزین اگر نوبیتکس جواب نداد؛ قیمت‌ها به تومان */
    private suspend fun wallex(): List<Quote> {
        val sy = JSONObject(get("https://api.wallex.ir/v1/markets")).getJSONObject("result").getJSONObject("symbols")
        return coins.mapNotNull { (s, n) ->
            val st = sy.optJSONObject(s.uppercase() + "TMN")?.optJSONObject("stats") ?: return@mapNotNull null
            val last = st.optString("lastPrice").toDoubleOrNull() ?: return@mapNotNull null
            Quote("$n (${s.uppercase()})", tm(last), st.optString("24h_ch").toDoubleOrNull(), logo = logo(s), id = "c-$s", num = last)
        }
    }

    private class Gk(val sym: String, val name: String, val image: String, val price: Double, val ch: Double?, val spark: List<Double>)

    /** کوین‌گکو: نمودار ۷ روزه + قیمت دلاری (برای نمودار و جایگزین نهایی) */
    private suspend fun gecko(): List<Gk> {
        val arr = JSONArray(get("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=60&page=1&sparkline=true"))
        return (0 until arr.length()).map {
            val c = arr.getJSONObject(it); val sp = c.optJSONObject("sparkline_in_7d")?.optJSONArray("price")
            Gk(c.getString("symbol").lowercase(), c.getString("name"), c.optString("image"), c.getDouble("current_price"),
                if (c.isNull("price_change_percentage_24h")) null else c.getDouble("price_change_percentage_24h"),
                if (sp == null) emptyList() else down((0 until sp.length()).map { i -> sp.getDouble(i) }))
        }
    }

    suspend fun prices(): List<Section> = coroutineScope {
        val iran = async { runCatching { tgju() }.getOrDefault(emptyList()) }
        val gk = async { runCatching { gecko() }.getOrDefault(emptyList()) }
        val ex = async {
            runCatching { nobitex() }.getOrNull()?.takeIf { it.isNotEmpty() }?.let { it to "نوبیتکس" }
                ?: runCatching { wallex() }.getOrNull()?.takeIf { it.isNotEmpty() }?.let { it to "والکس" }
        }
        val world = async {
            listOfNotNull(yahoo("GC=F", "اونس طلا", "$", "🥇"), yahoo("SI=F", "اونس نقره", "$", "🥈"),
                yahoo("BZ=F", "نفت برنت", "$", "🛢"), yahoo("CL=F", "نفت WTI", "$", "🛢"))
        }
        val ir = iran.await(); val g = gk.await(); val e = ex.await()
        val usd = ir.firstOrNull { it.id == "price_dollar_rl" }?.num ?: 0.0
        val sparks = g.associate { it.sym to it.spark }
        val (cq, ct) = when {
            e != null -> e.first.map { it.copy(spark = sparks[it.id.removePrefix("c-")].orEmpty()) } to "ارزهای دیجیتال به تومان • ${e.second}"
            usd > 0 -> g.take(15).map { c -> Quote("${coins.firstOrNull { it.first == c.sym }?.second ?: c.name} (${c.sym.uppercase()})", tm(c.price * usd),
                c.ch, logo = c.image, spark = c.spark, id = "c-${c.sym}") } to "ارزهای دیجیتال به تومان • تبدیل از نرخ دلار آزاد"
            else -> g.take(15).map { c -> Quote("${c.name} (${c.sym.uppercase()})", "$" + fmt(c.price, if (c.price < 1) 4 else 2), c.ch,
                logo = c.image, spark = c.spark, id = "c-${c.sym}") } to "ارزهای دیجیتال (دلار)"
        }
        listOf(
            Section("طلا، سکه و ارز (بازار ایران)", ir),
            Section(ct, cq),
            Section("بازار جهانی: طلا، نقره، نفت", world.await())
        ).filter { it.items.isNotEmpty() }
    }
}
