package ir.pricefinder

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit

data class Offer(
    val title: String, val priceToman: Long, val source: String, val url: String, val shop: String = "",
    val image: String = "", val key: String = "", val offline: Boolean = false, val city: String = "", val score: Double = 0.0
)
data class Quote(val name: String, val value: String, val change: Double?)
data class Section(val title: String, val items: List<Quote>)
private class Src(val name: String, val run: suspend () -> List<Offer>)

fun norm(s: String) = s.lowercase().map { when (it) { in '۰'..'۹' -> '0' + (it - '۰'); in '٠'..'٩' -> '0' + (it - '٠'); 'ي' -> 'ی'; 'ك' -> 'ک'; else -> it } }.joinToString("")
/** شباهت دو عنوان (۰ تا ۱) بر اساس کلمات مشترک */
fun sim(a: String, b: String): Double {
    val x = norm(a).split(" ", "‌", "-", "|").filter { it.length >= 2 }.toSet()
    val y = norm(b).split(" ", "‌", "-", "|").filter { it.length >= 2 }.toSet()
    if (x.isEmpty() || y.isEmpty()) return 0.0
    return x.intersect(y).size.toDouble() / minOf(x.size, y.size)
}

/** همه‌ی آدرس‌ها اینجاست؛ اگر سایتی API را عوض کرد فقط همین فایل را اصلاح کنید. */
object Api {
    private val client = OkHttpClient.Builder().callTimeout(9, TimeUnit.SECONDS).build()
    private const val UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"

    private suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).header("User-Agent", UA).header("Accept", "application/json").build()
        client.newCall(req).execute().use {
            if (!it.isSuccessful) error("HTTP ${it.code}")
            it.body!!.string()
        }
    }

    private suspend fun post(url: String, json: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).header("User-Agent", UA).header("Accept", "application/json")
            .post(json.toRequestBody("application/json".toMediaType())).build()
        client.newCall(req).execute().use {
            if (!it.isSuccessful) error("HTTP ${it.code}")
            it.body!!.string()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    // ---------- جستجوی قیمت ----------
    private suspend fun digikala(q: String): List<Offer> {
        val arr = JSONObject(get("https://api.digikala.com/v1/search/?q=${enc(q)}"))
            .getJSONObject("data").getJSONArray("products")
        val out = mutableListOf<Offer>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val rial = p.optJSONObject("default_variant")?.optJSONObject("price")?.optLong("selling_price", 0) ?: 0
            if (rial <= 0) continue
            val img = p.optJSONObject("images")?.optJSONObject("main")?.optJSONArray("url")?.optString(0).orEmpty()
            out += Offer(p.optString("title_fa"), rial / 10, "دیجی‌کالا",
                "https://www.digikala.com/product/dkp-${p.optInt("id")}/", image = img)
        }
        return out
    }

    private suspend fun torob(q: String): List<Offer> {
        val arr = JSONObject(get("https://api.torob.com/v4/base-product/search/?page=0&sort=popularity&size=24&query=${enc(q)}&q=${enc(q)}&source=next"))
            .optJSONArray("results") ?: return emptyList()
        val out = mutableListOf<Offer>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val price = p.optLong("price", 0)
            if (price <= 0) continue
            out += Offer(p.optString("name1"), price, "ترب", p.optString("web_client_absolute_url"), p.optString("shop_text"),
                image = p.optString("image_url"), key = p.optString("random_key"))
        }
        return out
    }

    /** فروشندگان یک محصول ترب (ده‌ها فروشگاه). نام فیلدها در پاسخ ترب را اینجا اصلاح کنید. */
    private fun isOffline(p: JSONObject): Boolean {
        val t = (p.optString("shop_type") + " " + p.optString("seller_type")).lowercase()
        return p.optBoolean("is_offline") || p.optBoolean("offline") || p.optBoolean("is_physical") ||
            p.optBoolean("has_physical_store") || "offline" in t || "physical" in t || "حضوری" in t
    }

    suspend fun sellers(key: String): List<Offer> {
        val j = JSONObject(get("https://api.torob.com/v4/base-product/sellers/?prk=${enc(key)}&sort=price&size=40&page=0"))
        val arr = j.optJSONArray("results") ?: j.optJSONObject("products_info")?.optJSONArray("result") ?: return emptyList()
        val out = mutableListOf<Offer>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val price = p.optLong("price", 0)
            if (price <= 0) continue
            val url = p.optString("page_url").ifBlank { p.optString("web_client_absolute_url") }
            if (url.isBlank()) continue
            out += Offer(p.optString("name1"), price, "ترب", url, p.optString("shop_name").ifBlank { p.optString("shop_text") },
                city = p.optString("shop_city").ifBlank { p.optString("city") }, offline = isOffline(p), score = p.optDouble("score", 0.0))
        }
        return out
    }

    /** محصولات مرتبط ترب (بدون لوازم جانبی و نتایج نامرتبط) که فروشندگانشان را می‌خوانیم */
    private suspend fun relevantBases(q: String, n: Int): List<Offer> {
        val all = torob(q).filter { it.key.isNotBlank() }
        if (all.isEmpty()) return all
        val med = all.map { it.priceToman }.sorted()[all.size / 2]
        val tokens = norm(q).split(" ", "\u200c").filter { it.length >= 2 }
        val byPrice = all.filter { it.priceToman >= med * 0.35 }
        val rel = byPrice.filter { b -> val t = norm(b.title); tokens.all { it in t } }
        return (if (rel.isNotEmpty()) rel else byPrice).take(n)
    }

    /** برای هر محصول، ارزان‌ترین پیشنهاد هر فروشگاهِ معتبر (امتیاز پایین حذف می‌شود؛ مقیاس score را اگر لازم بود تغییر دهید) */
    private suspend fun torobShops(q: String): List<Offer> = coroutineScope {
        val bases = relevantBases(q, 3)
        val per = bases.map { base ->
            async {
                runCatching { sellers(base.key) }.map { l ->
                    l.filter { it.score == 0.0 || it.score >= 3.5 }.map { it.copy(title = base.title, image = base.image, key = base.key) }
                        .groupBy { it.shop }.map { e -> e.value.minBy { it.priceToman } }.sortedBy { it.priceToman }.take(15)
                }
            }
        }.awaitAll()
        if (bases.isNotEmpty() && per.all { it.isFailure }) error("فروشندگان دریافت نشد")
        per.flatMap { it.getOrDefault(emptyList()) }
    }

    /** خرید حضوری: فقط فروشندگان حضوری همین محصولات ترب */
    private suspend fun torobOffline(q: String): List<Offer> = coroutineScope {
        relevantBases(q, 5).map { base ->
            async {
                runCatching { sellers(base.key) }.getOrDefault(emptyList()).filter { it.offline }
                    .map { it.copy(title = base.title, image = base.image, key = base.key) }
            }
        }.awaitAll().flatten()
    }

    // باسلام: جستجوی عمومی (POST/JSON). اگر آدرس یا ساختار پاسخ عوض شد فقط همین تابع را اصلاح کنید.
    private const val BASALAM_URL = "https://search.basalam.com/ai-engine/api/v2.0/product/search"

    private suspend fun basalam(q: String): List<Offer> {
        val body = JSONObject().put("q", q).put("rows", 24).put("start", 0).put("filters", JSONObject()).toString()
        val j = JSONObject(post(BASALAM_URL, body))
        val arr = j.optJSONArray("products") ?: j.optJSONObject("data")?.optJSONArray("products") ?: return emptyList()
        val out = mutableListOf<Offer>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val price = p.optLong("price", 0).takeIf { it > 0 } ?: p.optLong("primaryPrice", 0)
            val id = p.optLong("id", 0)
            if (price <= 0 || id <= 0) continue
            val title = p.optString("name").ifBlank { p.optString("title") }
            val shop = p.optJSONObject("vendor")?.optString("name").orEmpty()
            val ph = p.optJSONObject("photo")
            val img = ph?.optString("url").orEmpty().ifBlank { ph?.optJSONObject("MEDIUM")?.optString("url").orEmpty() }
            out += Offer(title, price, "باسلام", "https://basalam.com/p/$id", shop, image = img)
        }
        return out
    }

    // فروشگاه‌های ووکامرسی با API عمومی. فهرست را آزادانه ویرایش کنید؛ سایتی که جواب ندهد خودکار کنار گذاشته می‌شود.
    private val wooShops = listOf<Pair<String, String>>() // مثال: "example.ir" to "نام فروشگاه"

    private suspend fun woo(host: String, label: String, q: String): List<Offer> {
        val arr = JSONArray(get("https://$host/wp-json/wc/store/v1/products?search=${enc(q)}&per_page=12"))
        val out = mutableListOf<Offer>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i); val pr = p.optJSONObject("prices") ?: continue
            var v = pr.optString("price").toDoubleOrNull() ?: continue
            repeat(pr.optInt("currency_minor_unit", 0)) { v /= 10 }
            if (pr.optString("currency_code") == "IRR") v /= 10
            if (v <= 0) continue
            out += Offer(p.optString("name"), v.toLong(), label, p.optString("permalink"),
                image = p.optJSONArray("images")?.optJSONObject(0)?.optString("src").orEmpty())
        }
        return out
    }

    private fun fix(all: List<Offer>): List<Offer> {
        // اگر قیمت‌های باسلام حدود ۱۰ برابر بقیه بود (ریال به‌جای تومان)، خودکار اصلاح می‌شود
        val others = all.filter { it.source != "باسلام" }.map { it.priceToman }.sorted()
        val bas = all.filter { it.source == "باسلام" }.map { it.priceToman }.sorted()
        val rial = others.size >= 3 && bas.size >= 3 && others[others.size / 2] > 0 &&
            bas[bas.size / 2] / others[others.size / 2] >= 6
        return all.map { if (rial && it.source == "باسلام") it.copy(priceToman = it.priceToman / 10) else it }
            .distinctBy { it.url + it.shop }.sortedBy { it.priceToman }
    }

    /** همه‌ی منابع هم‌زمان؛ هر منبع که جواب داد، نتیجه بلافاصله به onUpdate می‌رسد (مرتب از ارزان به گران) */
    suspend fun search(q: String, offline: Boolean, onUpdate: (List<Offer>, List<String>) -> Unit) = coroutineScope {
        val sources: List<Src> = if (offline) listOf(Src("ترب (حضوری)") { torobOffline(q) })
        else listOf(Src("دیجی‌کالا") { digikala(q) }, Src("ترب") { torob(q) }, Src("فروشگاه‌های ترب") { torobShops(q) }, Src("باسلام") { basalam(q) }) +
            wooShops.map { (h, l) -> Src(l) { woo(h, l, q) } }
        val all = mutableListOf<Offer>(); val failed = mutableListOf<String>(); val mu = Mutex()
        sources.map { s ->
            launch {
                val r = runCatching { withTimeout(9000) { s.run() } }
                val snap = mu.withLock {
                    r.onSuccess { all += it }.onFailure { failed += s.name }
                    fix(all) to failed.toList()
                }
                withContext(Dispatchers.Main) { onUpdate(snap.first, snap.second) }
            }
        }
    }

    /** صفحه‌ی محصول: فروشندگان ترب + پیشنهادهای هم‌عنوان از سایر منابع، مرتب از ارزان به گران */
    suspend fun sellersFor(o: Offer, pool: List<Offer>): List<Offer> {
        val t = if (o.key.isNotBlank()) runCatching { sellers(o.key) }.getOrDefault(emptyList())
            .map { it.copy(title = o.title, image = o.image, key = o.key) } else emptyList()
        val others = pool.filter { it.source != "ترب" && !it.offline && sim(it.title, o.title) >= 0.6 }
        return (t + others + o).distinctBy { it.url + it.shop }.sortedBy { it.priceToman }
    }

    // ---------- قیمت‌های لحظه‌ای ----------
    private fun fmt(v: Double, dec: Int = 0) = String.format(Locale.US, "%,.${dec}f", v)

    private suspend fun tgju(): List<Quote> {
        val cur = JSONObject(get("https://call4.tgju.org/ajax.json")).getJSONObject("current")
        val keys = listOf(
            "price_dollar_rl" to "دلار آزاد", "price_eur" to "یورو",
            "geram18" to "طلای ۱۸ عیار (گرم)", "geram24" to "طلای ۲۴ عیار (گرم)",
            "sekee" to "سکه امامی", "silver" to "نقره"
        )
        return keys.mapNotNull { (k, name) ->
            val o = cur.optJSONObject(k) ?: return@mapNotNull null
            val toman = o.optString("p").replace(",", "").toDoubleOrNull()?.div(10) ?: return@mapNotNull null
            val dp = o.optString("dp").toDoubleOrNull()
            Quote(name, fmt(toman) + " تومان", dp?.let { if (o.optString("dt") == "low") -it else it })
        }
    }

    private suspend fun yahoo(sym: String, name: String, unit: String): Quote? = runCatching {
        val meta = JSONObject(get("https://query1.finance.yahoo.com/v8/finance/chart/$sym?interval=1d&range=1d"))
            .getJSONObject("chart").getJSONArray("result").getJSONObject(0).getJSONObject("meta")
        val p = meta.getDouble("regularMarketPrice")
        val prev = meta.optDouble("chartPreviousClose", Double.NaN)
        Quote(name, fmt(p, 2) + " $unit", if (prev.isNaN() || prev == 0.0) null else (p - prev) / prev * 100)
    }.getOrNull()

    private suspend fun crypto(): List<Quote> {
        val arr = org.json.JSONArray(get("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=15&page=1"))
        return (0 until arr.length()).map {
            val c = arr.getJSONObject(it)
            val price = c.getDouble("current_price")
            Quote("${c.getString("name")} (${c.getString("symbol").uppercase()})",
                "$" + fmt(price, if (price < 1) 4 else 2),
                if (c.isNull("price_change_percentage_24h")) null else c.getDouble("price_change_percentage_24h"))
        }
    }

    suspend fun prices(): List<Section> = coroutineScope {
        val iran = async { runCatching { tgju() }.getOrDefault(emptyList()) }
        val world = async {
            listOfNotNull(
                yahoo("GC=F", "اونس طلا", "$"), yahoo("SI=F", "اونس نقره", "$"),
                yahoo("BZ=F", "نفت برنت", "$"), yahoo("CL=F", "نفت WTI", "$")
            )
        }
        val coins = async { runCatching { crypto() }.getOrDefault(emptyList()) }
        listOf(
            Section("طلا، سکه و ارز (بازار ایران)", iran.await()),
            Section("بازار جهانی: طلا، نقره، نفت", world.await()),
            Section("۱۵ ارز دیجیتال برتر", coins.await())
        ).filter { it.items.isNotEmpty() }
    }
}
