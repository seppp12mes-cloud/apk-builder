package ir.pricefinder

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import org.json.JSONObject

data class RemoteCfg(
    val homeSubtitle: String = "", val searchSubtitle: String = "", val announcement: String = "", val announcementUrl: String = "",
    val categories: List<String> = emptyList(), val sections: List<HomeSec> = emptyList()
)

/**
 * محتوای قابل‌ویرایش از راه دور (متن‌ها، دسته‌ها، محصولات خودت).
 * برنامه فقط «می‌خواند»؛ هیچ پنل، رمز یا توکنی داخل برنامه نیست. ویرایش از «admin-panel.html» (روی کامپیوتر خودت) انجام می‌شود.
 * ⚠ آدرس فایل content.json را اینجا بگذارید (مثال GitHub raw: https://raw.githubusercontent.com/USER/REPO/main/content.json)
 */
object Remote {
    const val URL = ""

    var cfg by mutableStateOf(RemoteCfg())
        private set
    private lateinit var sp: SharedPreferences
    private var ownUrls: Set<String> = emptySet()
    private var own: List<Offer> = emptyList()

    fun init(c: Context) {
        sp = c.getSharedPreferences("pf_remote", 0)
        sp.getString("json", null)?.let { t -> try { apply(parse(t)) } catch (e: Exception) { sp.edit().remove("json").apply() } }
    }

    private fun apply(c: RemoteCfg) {
        cfg = c
        own = c.sections.flatMap { it.items }
        ownUrls = own.map { it.url }.toSet()
    }

    fun isOwn(o: Offer) = o.url in ownUrls

    /** جستجو در محصولات خودت (همه‌ی کلمات جستجو باید در عنوان باشد، یا شباهت بالا) */
    fun search(q: String): List<Offer> {
        val tokens = norm(q).split(" ", "\u200c").filter { it.length >= 2 }
        if (tokens.isEmpty()) return emptyList()
        return own.filter { o -> val t = norm(o.title); tokens.all { it in t } || sim(q, o.title) >= 0.6 }
    }

    private fun str(j: JSONObject?, k: String) = j?.optString(k).orEmpty().trim().takeIf { it != "null" }.orEmpty()

    private fun parse(txt: String): RemoteCfg {
        val j = JSONObject(txt)
        val t = j.optJSONObject("texts")
        val cats = j.optJSONArray("categories")?.let { a -> (0 until a.length()).map { a.optString(it).trim() }.filter { it.isNotEmpty() && it != "null" } }.orEmpty()
        val secs = mutableListOf<HomeSec>()
        val sa = j.optJSONArray("sections")
        if (sa != null) for (i in 0 until sa.length()) {
            val s = sa.optJSONObject(i) ?: continue
            val ia = s.optJSONArray("items") ?: continue
            val items = mutableListOf<Offer>()
            for (k in 0 until ia.length()) {
                val p = ia.optJSONObject(k) ?: continue
                val title = str(p, "title"); val price = p.optLong("price", 0)
                val url = Links.clean(str(p, "url"), ""); if (title.isEmpty() || price <= 0 || url.isEmpty()) continue
                val shop = str(p, "shop")
                items += Offer(title, price, shop.ifEmpty { "پیشنهاد ما" }, url, shop, image = Links.clean(str(p, "image"), ""), old = p.optLong("old", 0))
            }
            if (items.isNotEmpty()) secs += HomeSec(-1, str(s, "title").ifEmpty { "⭐ پیشنهاد ما" }, items, false, "")
        }
        return RemoteCfg(str(t, "homeSubtitle"), str(t, "searchSubtitle"), str(t, "announcement"), Links.clean(str(t, "announcementUrl"), ""), cats, secs)
    }

    /** یک‌بار می‌خواند؛ اگر خطا شد همان نسخه‌ی ذخیره‌شده‌ی قبلی می‌ماند (برنامه هیچ‌وقت خالی نمی‌شود) */
    suspend fun refresh() {
        if (URL.isBlank()) return
        try {
            val txt = Api.fetchFresh(URL)
            val c = parse(txt)
            sp.edit().putString("json", txt).apply()
            apply(c)
        } catch (e: CancellationException) { throw e } catch (e: Exception) { /* آفلاین یا فایل خراب: نسخه‌ی قبلی بماند */ }
    }

    /** هر ۲ دقیقه وقتی برنامه جلوی چشم است */
    suspend fun loop() {
        while (true) {
            if (!Mkt.fg.value) Mkt.fg.first { it }
            refresh()
            delay(120_000)
        }
    }
}
