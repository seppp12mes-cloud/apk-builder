@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package ir.pricefinder

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridItemSpanScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import kotlinx.coroutines.Job
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.border
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


object Store {
    private lateinit var sp: SharedPreferences
    val favs = mutableStateListOf<Offer>()
    val history = mutableStateListOf<String>()
    fun init(c: Context) {
        sp = c.getSharedPreferences("pf", 0)
        runCatching {
            val a = JSONArray(sp.getString("f", "[]"))
            for (i in 0 until a.length()) a.getJSONObject(i).let { favs += Offer(it.getString("t"), it.getLong("p"), it.getString("s"), it.getString("u"), it.optString("sh"), image = it.optString("i")) }
        }
        history += sp.getString("h", "")!!.split("\n").filter { it.isNotBlank() }
    }
    fun toggleFav(o: Offer) { if (!favs.remove(o)) favs.add(0, o); sp.edit().putString("f", JSONArray(favs.map {
        JSONObject().put("t", it.title).put("p", it.priceToman).put("s", it.source).put("u", it.url).put("sh", it.shop).put("i", it.image) }).toString()).apply() }
    fun addHistory(q: String) { history.remove(q); history.add(0, q); while (history.size > 10) history.removeLast()
        sp.edit().putString("h", history.joinToString("\n")).apply() }
    fun clearHistory() { history.clear(); sp.edit().remove("h").apply() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Bg)) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    Box(Modifier.fillMaxSize()) {
        AnimatedBackground()
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f)) { when (tab) { 0 -> SearchScreen(); 1 -> PricesScreen(); else -> FavsScreen() } }
            NavBar(tab) { tab = it }
        }
    }
}

@Composable
fun NavBar(sel: Int, onSel: (Int) -> Unit) {
    val items = listOf("🏠" to "خانه", "💹" to "قیمت‌ها", "⭐" to "نشان‌شده‌ها")
    GlassCard(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            items.forEachIndexed { i, (ic, l) ->
                val on = i == sel
                Column(Modifier.clip(RoundedCornerShape(16.dp))
                    .background(if (on) Brush.linearGradient(listOf(Cyan.copy(.35f), Violet.copy(.35f))) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
                    .clickable { onSel(i) }.padding(horizontal = 18.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(ic, fontSize = if (on) 24.sp else 20.sp)
                    Text(l, fontSize = 11.sp, color = if (on) Color.White else Dim, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
fun Header(subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 6.dp)) {
        Logo()
        Spacer(Modifier.width(12.dp))
        Column {
            Text("قیمت‌یاب", style = TextStyle(brush = Brand, fontSize = 30.sp, fontWeight = FontWeight.Black))
            Text(subtitle, color = Dim, fontSize = 12.sp)
        }
    }
}

private object S {
    var query by mutableStateOf(""); var offers by mutableStateOf<List<Offer>>(emptyList())
    var failed by mutableStateOf<List<String>>(emptyList()); var loading by mutableStateOf(false)
    var searched by mutableStateOf(false); var asc by mutableStateOf(true)
    var hidden by mutableStateOf<Set<String>>(emptySet()); var smart by mutableStateOf(true)
    var offline by mutableStateOf(false); var detail by mutableStateOf<Offer?>(null)
    var job: Job? = null
}
private val FULL: LazyGridItemSpanScope.() -> GridItemSpan = { GridItemSpan(maxLineSpan) }
private fun toman(v: Long) = String.format(Locale.US, "%,d", v) + " تومان"
private fun medalOf(rank: Int) = when (rank) { 0 -> "🥇"; 1 -> "🥈"; 2 -> "🥉"; else -> "${rank + 1}" }

/** فیلتر هوشمند: حذف لوازم جانبی و نتایج نامرتبط (قیمت خیلی پایین‌تر از میانه یا نبودن کلمات جستجو در عنوان) */
private fun smartFilter(list: List<Offer>, q: String): List<Offer> {
    if (list.size < 4) return list
    val med = list.map { it.priceToman }.sorted()[list.size / 2]
    val byPrice = list.filter { it.priceToman >= med * 0.35 }
    val tokens = norm(q).split(" ", "\u200c").filter { it.length >= 2 }
    val rel = byPrice.filter { o -> val t = norm(o.title); tokens.all { it in t } }
    return if (rel.size >= 3) rel else if (byPrice.size >= 3) byPrice else list
}

@Composable
fun SearchScreen() {
    val scope = rememberCoroutineScope()
    fun go(q: String = S.query) {
        if (q.isBlank()) return
        S.job?.cancel()
        S.query = q; S.loading = true; S.hidden = emptySet(); S.searched = true; S.offers = emptyList(); S.failed = emptyList()
        Store.addHistory(q.trim())
        S.job = scope.launch { Api.search(q.trim(), S.offline) { o, f -> S.offers = o; S.failed = f }; S.loading = false }
    }
    val base = S.offers.filter { it.source !in S.hidden }
    val clean = if (S.smart && !S.offline) smartFilter(base, S.query) else base
    val shown = if (S.asc) clean else clean.reversed()
    val min = clean.minOfOrNull { it.priceToman } ?: 0L
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Spacer(Modifier.height(10.dp))
        Header("هر کالایی بنویس؛ از دیجی‌کالا و ده‌ها فروشگاه ارزان‌ترین را پیدا می‌کنیم ✨")
        OutlinedTextField(S.query, { S.query = it }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), singleLine = true,
            placeholder = { Text("مثلاً: تلویزیون، آیفون ۱۷، پلی‌استیشن ۵…", color = Dim) },
            leadingIcon = { Text("🔍", fontSize = 18.sp, modifier = Modifier.padding(start = 8.dp).clickable { go() }) },
            trailingIcon = { if (S.query.isNotEmpty()) Text("✕", color = Dim, modifier = Modifier.padding(end = 12.dp).clickable { S.query = "" }) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { go() }),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Color(0x66FFFFFF),
                focusedContainerColor = Color(0x1AFFFFFF), unfocusedContainerColor = Color(0x14FFFFFF)))
        if (S.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Pink, trackColor = Color(0x22FFFFFF))
        LazyRow(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(S.offline, { S.offline = !S.offline; if (S.query.isNotBlank()) go() }, { Text("🏬 خرید حضوری (فروشگاه‌های ترب)") }) }
            item { FilterChip(true, { S.asc = !S.asc }, { Text(if (S.asc) "⬆ ارزان به گران" else "⬇ گران به ارزان") }) }
            if (!S.offline) item { FilterChip(S.smart, { S.smart = !S.smart }, { Text("🧹 حذف لوازم جانبی") }) }
            items(S.offers.map { it.source }.distinct()) { src ->
                FilterChip(src !in S.hidden, { S.hidden = if (src in S.hidden) S.hidden - src else S.hidden + src }, { Text(src) })
            }
        }
        LazyVerticalGrid(GridCells.Fixed(2), Modifier.fillMaxSize().padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!S.searched) item(span = FULL) {
                Column {
                    Text("دسته‌های پرطرفدار", Modifier.padding(top = 8.dp), fontWeight = FontWeight.Bold, color = Color.White)
                    LazyRow(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("📱 گوشی موبایل", "💻 لپ‌تاپ", "🎧 هدفون بلوتوث", "📺 تلویزیون", "⌚ ساعت هوشمند", "🎮 کنسول بازی", "👟 کفش ورزشی", "🧊 یخچال")) {
                            AssistChip({ go(it.substringAfter(" ")) }, { Text(it, color = Color.White) }, shape = RoundedCornerShape(14.dp),
                                colors = AssistChipDefaults.assistChipColors(containerColor = Color(0x22FFFFFF)),
                                border = AssistChipDefaults.assistChipBorder(true, borderColor = Color(0x44FFFFFF)))
                        }
                    }
                    if (Store.history.isNotEmpty()) {
                        Row(Modifier.padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("جستجوهای اخیر", Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Color.White)
                            TextButton({ Store.clearHistory() }) { Text("پاک کردن", color = Pink) }
                        }
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(Store.history.toList()) {
                            SuggestionChip({ go(it) }, { Text("🕘 $it", color = Color.White) }, shape = RoundedCornerShape(14.dp)) } }
                    }
                }
            }
            if (S.failed.isNotEmpty() && !S.loading) item(span = FULL) {
                Column {
                    Text("پاسخ نداد: " + S.failed.joinToString("، "), color = Coral, fontSize = 12.sp)
                    Text("اگر فیلترشکن روشن است خاموشش کنید؛ بعضی فروشگاه‌ها IP خارج از ایران را رد می‌کنند.", color = Dim, fontSize = 11.sp)
                }
            }
            if (S.searched && clean.isEmpty() && !S.loading) item(span = FULL) {
                Text(if (S.offline) "فروشگاه حضوری‌ای برای این کالا در ترب پیدا نشد." else "نتیجه‌ای پیدا نشد؛ اینترنت یا کلمه‌ی جستجو را بررسی کنید.", color = Dim)
            }
            if (clean.isNotEmpty()) item(span = FULL) {
                val ps = clean.map { it.priceToman }; val max = ps.max(); val avg = ps.average().toLong(); val save = if (max > 0) (max - min) * 100 / max else 0
                GlassCard(Modifier.fillMaxWidth(), glow = true) {
                    Text("خلاصه‌ی بازار • ${ps.size} پیشنهاد از ${clean.map { it.shop.ifBlank { it.source } }.distinct().size} فروشگاه", fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    Row { Column(Modifier.weight(1f)) { Text("ارزان‌ترین", color = Dim, fontSize = 11.sp); Text(toman(min), color = Mint, fontWeight = FontWeight.Black, fontSize = 15.sp) }
                          Column(Modifier.weight(1f)) { Text("میانگین", color = Dim, fontSize = 11.sp); Text(toman(avg), color = Color.White, fontSize = 13.sp) }
                          Column(Modifier.weight(1f)) { Text("گران‌ترین", color = Dim, fontSize = 11.sp); Text(toman(max), color = Coral, fontSize = 13.sp) } }
                    Text("💡 خرید از ارزان‌ترین تا $save٪ صرفه‌جویی دارد (${toman(max - min)})", color = Amber, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
            gridItemsIndexed(shown) { i, o ->
                val rank = if (S.asc) i else shown.size - 1 - i
                ProductCard(o, rank, min) { S.detail = o }
            }
            item(span = FULL) { Spacer(Modifier.height(10.dp)) }
        }
    }
    S.detail?.let { DetailSheet(it, S.offers) { S.detail = null } }
}

/** کارت مربعی هم‌اندازه: عکس بالا، متن پایین */
@Composable
fun ProductCard(o: Offer, rank: Int, min: Long, onClick: () -> Unit) {
    val diff = if (min > 0) (o.priceToman - min) * 100 / min else 0
    GlassCard(Modifier.fillMaxWidth(), glow = rank == 0, onClick = onClick) {
        Box {
            AsyncImage(o.image.ifBlank { null }, null, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(14.dp)).background(Color.White),
                contentScale = ContentScale.Fit)
            Text(medalOf(rank), fontSize = if (rank < 3) 24.sp else 13.sp, color = Color.White, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopStart).padding(4.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x99070B1E)).padding(horizontal = 7.dp, vertical = 2.dp))
            Text(if (o in Store.favs) "⭐" else "☆", fontSize = 22.sp, color = Amber,
                modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x99070B1E))
                    .clickable { Store.toggleFav(o) }.padding(horizontal = 6.dp, vertical = 1.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(o.title, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = Color.White)
        Spacer(Modifier.height(4.dp))
        SourceChip(o.source)
        Text(if (o.offline) "🏬 " + listOf(o.shop, o.city).filter { it.isNotBlank() }.joinToString(" • ") else o.shop.ifBlank { " " },
            color = Dim, fontSize = 11.sp, maxLines = 1, minLines = 1, overflow = TextOverflow.Ellipsis)
        Text(toman(o.priceToman), fontWeight = FontWeight.Black, color = Mint, fontSize = 13.sp)
        Text(if (diff in 1..999) "+$diff٪ از ارزان‌ترین" else if (rank == 0) "👑 بهترین پیشنهاد" else " ",
            color = if (rank == 0) Amber else Coral, fontSize = 11.sp, maxLines = 1, minLines = 1)
    }
}

/** صفحه‌ی محصول: عکس بزرگ + رتبه‌بندی فروشگاه‌ها (مدال طلا/نقره/برنز) از ارزان به گران */
@Composable
fun DetailSheet(o: Offer, pool: List<Offer>, onClose: () -> Unit) {
    val uri = LocalUriHandler.current
    var list by remember(o) { mutableStateOf<List<Offer>?>(null) }
    var onlyOffline by remember(o) { mutableStateOf(S.offline) }
    LaunchedEffect(o) { list = Api.sellersFor(o, pool) }
    val rows = list?.let { l -> if (onlyOffline) l.filter { it.offline } else l }
    ModalBottomSheet(onClose, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = Bg) {
        LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                AsyncImage(o.image.ifBlank { null }, null, Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(16.dp)).background(Color.White),
                    contentScale = ContentScale.Fit)
                Text(o.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp))
                Text("فروشگاه‌ها از ارزان به گران", color = Dim, fontSize = 12.sp)
                if (list?.any { it.offline } == true)
                    FilterChip(onlyOffline, { onlyOffline = !onlyOffline }, { Text("🏬 فقط حضوری") }, modifier = Modifier.padding(top = 4.dp))
                if (rows == null) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Pink)
            }
            gridOrList(rows.orEmpty(), uri)
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.gridOrList(rows: List<Offer>, uri: androidx.compose.ui.platform.UriHandler) {
    itemsIndexed(rows) { i, r ->
        GlassCard(Modifier.fillMaxWidth(), glow = i == 0, onClick = { runCatching { uri.openUri(r.url) } }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(medalOf(i), fontSize = if (i < 3) 28.sp else 16.sp, modifier = Modifier.width(42.dp), color = Color.White)
                Column(Modifier.weight(1f)) {
                    Text(r.shop.ifBlank { r.source }, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SourceChip(r.source)
                        if (r.offline) Text("  🏬 حضوری ${r.city}", color = Amber, fontSize = 11.sp)
                    }
                }
                Text(toman(r.priceToman), fontWeight = FontWeight.Black, color = Mint, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun SourceChip(name: String) {
    val b = when (name) {
        "دیجی‌کالا" -> listOf(Color(0xFFFF4D6D), Color(0xFFEF394E)); "باسلام" -> listOf(Color(0xFF00D4B4), Color(0xFF00A88F))
        "ترب", "ترب (حضوری)" -> listOf(Color(0xFF38BDF8), Color(0xFF2563EB))
        else -> { val h = (name.hashCode() and 0xFFFF) % 360f; listOf(Color.hsv(h, .55f, .85f), Color.hsv((h + 30) % 360f, .65f, .7f)) }
    }
    Box(Modifier.clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(b)).padding(horizontal = 10.dp, vertical = 2.dp)) {
        Text(name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun FavsScreen() {
    val uri = LocalUriHandler.current; val ctx = LocalContext.current
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Header("پیشنهادهای نشان‌شده‌ی شما ⭐")
            if (Store.favs.isEmpty()) Text("هنوز چیزی نشان نکرده‌اید. روی ☆ کنار هر نتیجه بزنید.", color = Dim, modifier = Modifier.padding(top = 8.dp))
        }
        items(Store.favs.toList()) { o ->
            GlassCard(Modifier.fillMaxWidth(), onClick = { runCatching { uri.openUri(o.url) } }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(o.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, color = Color.White); Spacer(Modifier.height(5.dp)); SourceChip(o.source) }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(toman(o.priceToman), color = Mint, fontWeight = FontWeight.Black, fontSize = 14.sp)
                        Row { Text("📤", fontSize = 22.sp, modifier = Modifier.clickable {
                            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                                .putExtra(Intent.EXTRA_TEXT, "${o.title}\n${toman(o.priceToman)} — ${o.source}\n${o.url}"), null)) })
                            Spacer(Modifier.width(14.dp)); Text("🗑", fontSize = 22.sp, modifier = Modifier.clickable { Store.toggleFav(o) }) }
                    }
                }
            }
        }
    }
}

@Composable
fun PricesScreen() {
    var sections by remember { mutableStateOf<List<Section>>(emptyList()) }
    var updated by remember { mutableStateOf("") }; var failed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            val r = runCatching { Api.prices() }.getOrDefault(emptyList())
            if (r.isEmpty()) failed = true else { sections = r; failed = false; updated = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) }
            delay(30_000)
        }
    }
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Header("قیمت‌های زنده • هر ۳۰ ثانیه ⚡")
            if (updated.isNotEmpty()) Text("آخرین به‌روزرسانی: $updated", fontSize = 12.sp, color = Dim)
            if (failed) Text("دریافت قیمت‌ها ناموفق بود؛ اینترنت را بررسی کنید.", color = Coral)
            else if (sections.isEmpty()) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Pink, trackColor = Color(0x22FFFFFF))
        }
        sections.forEach { s ->
            item { Text(s.title, style = TextStyle(brush = Brand, fontSize = 16.sp, fontWeight = FontWeight.Black), modifier = Modifier.padding(top = 12.dp)) }
            items(s.items) { q ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(q.name, Modifier.weight(1f), fontSize = 14.sp, color = Color.White)
                        Column(horizontalAlignment = Alignment.End) {
                            Text(q.value, fontWeight = FontWeight.Black, fontSize = 14.sp, color = Color.White)
                            q.change?.let { Text((if (it >= 0) "▲ " else "▼ ") + String.format(Locale.US, "%.2f%%", Math.abs(it)), fontSize = 12.sp, color = if (it >= 0) Mint else Coral) }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(10.dp)) }
    }
}
