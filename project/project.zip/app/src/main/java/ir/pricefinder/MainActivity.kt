@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package ir.pricefinder

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF0B0F1A); private val Card = Color(0xFF151B2B)
private val Accent = Color(0xFF7DD3FF); private val Violet = Color(0xFFB6A3FF)
private val Good = Color(0xFF6FD9AC); private val Bad = Color(0xFFEF7A72); private val Dim = Color(0xFF8B95AB)

object Store {
    private lateinit var sp: SharedPreferences
    val favs = mutableStateListOf<Offer>()
    val history = mutableStateListOf<String>()
    fun init(c: Context) {
        sp = c.getSharedPreferences("pf", 0)
        runCatching {
            val a = JSONArray(sp.getString("f", "[]"))
            for (i in 0 until a.length()) a.getJSONObject(i).let { favs += Offer(it.getString("t"), it.getLong("p"), it.getString("s"), it.getString("u"), it.optString("sh")) }
        }
        history += sp.getString("h", "")!!.split("\n").filter { it.isNotBlank() }
    }
    fun toggleFav(o: Offer) { if (!favs.remove(o)) favs.add(0, o); sp.edit().putString("f", JSONArray(favs.map {
        JSONObject().put("t", it.title).put("p", it.priceToman).put("s", it.source).put("u", it.url).put("sh", it.shop) }).toString()).apply() }
    fun addHistory(q: String) { history.remove(q); history.add(0, q); while (history.size > 10) history.removeLast()
        sp.edit().putString("h", history.joinToString("\n")).apply() }
    fun clearHistory() { history.clear(); sp.edit().remove("h").apply() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card)) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Card) {
            listOf("🏠" to "خانه", "💹" to "قیمت‌ها", "⭐" to "نشان‌شده‌ها").forEachIndexed { i, (ic, l) ->
                NavigationBarItem(tab == i, { tab = i }, { Text(ic, fontSize = 20.sp) }, label = { Text(l) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF111A33), Bg)))) {
            when (tab) { 0 -> SearchScreen(); 1 -> PricesScreen(); else -> FavsScreen() }
        }
    }
}

private object S {
    var query by mutableStateOf(""); var offers by mutableStateOf<List<Offer>>(emptyList())
    var failed by mutableStateOf<List<String>>(emptyList()); var loading by mutableStateOf(false)
    var searched by mutableStateOf(false); var asc by mutableStateOf(true); var hidden by mutableStateOf<Set<String>>(emptySet())
}
private fun toman(v: Long) = String.format(Locale.US, "%,d", v) + " تومان"

@Composable
fun SearchScreen() {
    val scope = rememberCoroutineScope(); val uri = LocalUriHandler.current
    fun go(q: String = S.query) {
        if (q.isBlank() || S.loading) return
        S.query = q; S.loading = true; S.hidden = emptySet(); Store.addHistory(q.trim())
        scope.launch { val (o, f) = Api.search(q.trim()); S.offers = o; S.failed = f; S.searched = true; S.loading = false }
    }
    val shown = S.offers.filter { it.source !in S.hidden }.let { if (S.asc) it else it.reversed() }
    val min = S.offers.filter { it.source !in S.hidden }.minOfOrNull { it.priceToman } ?: 0L
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Spacer(Modifier.height(12.dp))
            Text("قیمت‌یاب ✦", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Accent)
            Text("هر کالایی بنویسید؛ ارزان‌ترین فروشگاه را پیدا می‌کنیم", color = Dim, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(S.query, { S.query = it }, Modifier.weight(1f), shape = RoundedCornerShape(16.dp),
                    placeholder = { Text("مثلاً: آیفون ۱۵، پلی‌استیشن ۵...") }, singleLine = true)
                Spacer(Modifier.width(8.dp))
                Button({ go() }, enabled = !S.loading, shape = RoundedCornerShape(14.dp)) { Text("🔍") }
            }
            if (S.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 8.dp))
            if (!S.searched) {
                Text("دسته‌های پرطرفدار", Modifier.padding(top = 14.dp, bottom = 4.dp), fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("گوشی موبایل", "لپ‌تاپ", "هدفون بلوتوث", "تلویزیون", "ساعت هوشمند", "کنسول بازی", "کفش ورزشی", "یخچال")) {
                        AssistChip({ go(it) }, { Text(it) })
                    }
                }
                if (Store.history.isNotEmpty()) {
                    Row(Modifier.padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("جستجوهای اخیر", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        TextButton({ Store.clearHistory() }) { Text("پاک کردن") }
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(Store.history.toList()) { SuggestionChip({ go(it) }, { Text("🕘 $it") }) } }
                }
            }
            if (S.failed.isNotEmpty()) Text("پاسخ نداد: " + S.failed.joinToString("، "), color = Bad, fontSize = 12.sp)
            if (S.searched && S.offers.isEmpty() && !S.loading) Text("نتیجه‌ای پیدا نشد؛ اینترنت یا کلمه‌ی جستجو را بررسی کنید.", Modifier.padding(top = 16.dp))
            if (S.offers.isNotEmpty()) {
                val ps = S.offers.filter { it.source !in S.hidden }.map { it.priceToman }
                if (ps.isNotEmpty()) {
                    val max = ps.max(); val avg = ps.average().toLong(); val save = if (max > 0) (max - min) * 100 / max else 0
                    Card(Modifier.fillMaxWidth().padding(top = 12.dp), colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(14.dp)) {
                            Text("خلاصه‌ی بازار (${ps.size} پیشنهاد)", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text("ارزان‌ترین: " + toman(min), color = Good)
                            Text("میانگین: " + toman(avg)); Text("گران‌ترین: " + toman(max), color = Bad)
                            Text("اختلاف تا $save٪ — انتخاب ارزان‌تر یعنی صرفه‌جویی ${toman(max - min)}", color = Violet, fontSize = 12.sp)
                        }
                    }
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(true, { S.asc = !S.asc }, { Text(if (S.asc) "⬆ ارزان به گران" else "⬇ گران به ارزان") })
                    S.offers.map { it.source }.distinct().forEach { src ->
                        FilterChip(src !in S.hidden, { S.hidden = if (src in S.hidden) S.hidden - src else S.hidden + src }, { Text(src) })
                    }
                }
            }
        }
        itemsIndexed(shown) { i, o ->
            val rank = if (S.asc) i else shown.size - 1 - i
            val medal = when (rank) { 0 -> "🥇"; 1 -> "🥈"; 2 -> "🥉"; else -> "${rank + 1}" }
            val diff = if (min > 0) (o.priceToman - min) * 100 / min else 0
            Card(Modifier.fillMaxWidth().clickable { runCatching { uri.openUri(o.url) } }, colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(medal, fontSize = if (rank < 3) 28.sp else 16.sp, modifier = Modifier.width(42.dp))
                    Column(Modifier.weight(1f)) {
                        Text(o.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                        Spacer(Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SourceChip(o.source)
                            if (o.shop.isNotBlank()) Text("  ${o.shop}", color = Dim, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, false))
                            if (diff > 0) Text("  +$diff٪", color = Bad, fontSize = 11.sp)
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(toman(o.priceToman), fontWeight = FontWeight.Bold, color = Good, fontSize = 14.sp)
                        Text(if (o in Store.favs) "⭐" else "☆", fontSize = 22.sp, modifier = Modifier.clickable { Store.toggleFav(o) })
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
fun SourceChip(name: String) {
    val c = when (name) { "دیجی‌کالا" -> Color(0xFFEF394E); "باسلام" -> Color(0xFF00A88F); else -> Color(0xFF1976D2) }
    Surface(color = c, shape = RoundedCornerShape(50)) { Text(name, color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 2.dp)) }
}

@Composable
fun FavsScreen() {
    val uri = LocalUriHandler.current; val ctx = LocalContext.current
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("نشان‌شده‌ها ⭐", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Accent)
            if (Store.favs.isEmpty()) Text("هنوز چیزی نشان نکرده‌اید. روی ☆ کنار هر نتیجه بزنید.", color = Dim, modifier = Modifier.padding(top = 8.dp)) }
        items(Store.favs.toList()) { o ->
            Card(Modifier.fillMaxWidth().clickable { runCatching { uri.openUri(o.url) } }, colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(o.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp); SourceChip(o.source) }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(toman(o.priceToman), color = Good, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Row { Text("📤", fontSize = 20.sp, modifier = Modifier.clickable {
                            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                                .putExtra(Intent.EXTRA_TEXT, "${o.title}\n${toman(o.priceToman)} — ${o.source}\n${o.url}"), null)) })
                            Spacer(Modifier.width(12.dp)); Text("🗑", fontSize = 20.sp, modifier = Modifier.clickable { Store.toggleFav(o) }) }
                    }
                }
            }
        }
    }
}

@Composable
fun PricesScreen() {
    var sections by remember { mutableStateOf<List<Section>>(emptyList()) }
    var updated by remember { mutableStateOf("") }; var failed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            val r = runCatching { Api.prices() }.getOrDefault(emptyList())
            if (r.isEmpty()) failed = true else { sections = r; failed = false; updated = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) }
            delay(30_000)
        }
    }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            Text("قیمت‌های لحظه‌ای 💹", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Accent)
            if (updated.isNotEmpty()) Text("آخرین به‌روزرسانی: $updated  •  هر ۳۰ ثانیه", fontSize = 12.sp, color = Dim)
            if (failed) Text("دریافت قیمت‌ها ناموفق بود؛ اینترنت را بررسی کنید.", color = Bad)
            else if (sections.isEmpty()) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
        }
        sections.forEach { s ->
            item { Text(s.title, fontWeight = FontWeight.Bold, color = Violet, modifier = Modifier.padding(top = 12.dp)) }
            items(s.items) { q ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(q.name, Modifier.weight(1f), fontSize = 14.sp)
                        Column(horizontalAlignment = Alignment.End) {
                            Text(q.value, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            q.change?.let { Text(String.format(Locale.US, "%+.2f%%", it), fontSize = 12.sp, color = if (it >= 0) Good else Bad) }
                        }
                    }
                }
            }
        }
    }
}
