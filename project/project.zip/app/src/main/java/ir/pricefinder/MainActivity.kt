@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package ir.pricefinder

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridItemSpanScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.ui.layout.ContentScale
import coil.Coil
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache
import okhttp3.OkHttpClient
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.style.TextDecoration
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.border
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


object Store {
    private lateinit var sp: SharedPreferences
    val favs = mutableStateListOf<Offer>()
    val history = mutableStateListOf<String>()
    /** هویت یک پیشنهاد: قیمت عوض شود هم همان پیشنهاد است */
    fun fid(o: Offer) = o.url + "|" + o.shop
    fun init(c: Context) {
        sp = c.getSharedPreferences("pf", 0)
        runCatching {
            val a = JSONArray(sp.getString("f", "[]"))
            for (i in 0 until a.length()) runCatching {
                a.getJSONObject(i).let {
                    favs += Offer(it.getString("t"), it.getLong("p"), it.getString("s"), it.getString("u"), it.optString("sh"), image = it.optString("i"),
                        key = it.optString("k"), offline = it.optBoolean("o"), city = it.optString("c"), old = it.optLong("old"), agg = it.optBoolean("a"))
                }
            }
        }
        history += sp.getString("h", "")!!.split("\n").filter { it.isNotBlank() }
    }
    private fun save() = sp.edit().putString("f", JSONArray(favs.map {
        JSONObject().put("t", it.title).put("p", it.priceToman).put("s", it.source).put("u", it.url).put("sh", it.shop).put("i", it.image)
            .put("k", it.key).put("o", it.offline).put("c", it.city).put("old", it.old).put("a", it.agg) }).toString()).apply()
    fun isFav(o: Offer) = favs.any { fid(it) == fid(o) }
    /** true = اضافه شد، false = حذف شد */
    fun toggleFav(o: Offer): Boolean {
        val i = favs.indexOfFirst { fid(it) == fid(o) }
        return if (i >= 0) { favs.removeAt(i); save(); false } else { favs.add(0, o.copy(verified = false)); save(); true }
    }
    fun setPrice(o: Offer, p: Long) {
        val i = favs.indexOfFirst { fid(it) == fid(o) }
        if (i >= 0 && p > 0 && favs[i].priceToman != p) { favs[i] = favs[i].copy(priceToman = p); save() }
    }
    /** قیمت همه‌ی نشان‌شده‌ها را از سایت اصلی دوباره می‌گیرد */
    suspend fun refreshPrices() {
        val sem = Semaphore(4)
        val res = coroutineScope { favs.toList().map { o -> async { sem.withPermit { o to Api.verify(o) } } }.awaitAll() }
        res.forEach { (o, p) -> if (p != null) setPrice(o, p) }
    }
    fun addHistory(q: String) { history.remove(q); history.add(0, q); while (history.size > 10) history.removeLast()
        sp.edit().putString("h", history.joinToString("\n")).apply() }
    fun clearHistory() { history.clear(); sp.edit().remove("h").apply() }
}

class MainActivity : ComponentActivity() {
    override fun onStart() { super.onStart(); Mkt.setForeground(true) }
    override fun onStop() { super.onStop(); Mkt.setForeground(false) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        Remote.init(this)
        Coil.setImageLoader(ImageLoader.Builder(this)
            .okHttpClient {
                OkHttpClient.Builder().addInterceptor { c ->
                    val r = c.request(); val ref = "https://" + r.url.host.split('.').takeLast(2).joinToString(".") + "/"
                    c.proceed(r.newBuilder().header("User-Agent", "Mozilla/5.0 (Linux; Android 13) Chrome/120 Mobile Safari/537.36")
                        .header("Referer", ref).header("Accept", "image/webp,image/*,*/*").build())
                }.build()
            }
            .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.25).build() }
            .diskCache { DiskCache.Builder().directory(cacheDir.resolve("img")).maxSizeBytes(120L * 1024 * 1024).build() }
            .allowHardware(false).respectCacheHeaders(false).crossfade(true).build())
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Bg)) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { Mkt.run() }
    LaunchedEffect(Unit) { Remote.loop() }
    Box(Modifier.fillMaxSize()) {
        AnimatedBackground()
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f)) { when (tab) { 0 -> HomeScreen { S.pending = it; tab = 1 }; 1 -> SearchScreen(); 2 -> PricesScreen(); else -> FavsScreen() } }
            NavBar(tab) { tab = it }
        }
    }
}

@Composable
fun NavBar(sel: Int, onSel: (Int) -> Unit) {
    val items = listOf("🏠" to "خانه", "🔍" to "جستجو", "💹" to "قیمت‌ها", "⭐" to "نشان‌شده‌ها")
    GlassCard(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            items.forEachIndexed { i, (ic, l) ->
                val on = i == sel
                Column(Modifier.clip(RoundedCornerShape(16.dp))
                    .background(if (on) Brush.linearGradient(listOf(Cyan.copy(.35f), Violet.copy(.35f))) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
                    .clickable { onSel(i) }.padding(horizontal = 12.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(ic, fontSize = if (on) 24.sp else 20.sp)
                    Text(l, fontSize = 11.sp, color = if (on) Color.White else Dim, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
fun Header(subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 6.dp)) {
        Logo()
        Spacer(Modifier.width(12.dp))
        Column {
            Text("قیمت‌یاب", style = TextStyle(brush = Brand, fontSize = 30.sp, fontWeight = FontWeight.Black))
            Text(subtitle, color = Dim, fontSize = 12.sp)
        }
    }
}

private object S {
    var query by mutableStateOf(""); var offers by mutableStateOf<List<Offer>>(emptyList())
    var failed by mutableStateOf<List<String>>(emptyList()); var loading by mutableStateOf(false)
    var searched by mutableStateOf(false); var asc by mutableStateOf(true)
    var hidden by mutableStateOf<Set<String>>(emptySet()); var smart by mutableStateOf(true)
    var offline by mutableStateOf(false); var detail by mutableStateOf<Offer?>(null)
    var job: Job? = null
    val alive = mutableStateMapOf<String, Boolean>() // وضعیت سالم‌بودن لینک فروشنده؛ false = صفحه وجود ندارد (پنهان می‌شود)
    val live = mutableStateMapOf<String, Long>() // قیمت تأییدشده از سایت اصلی: >0 تأیید، 0 در حال بررسی، -1 ناموفق
    var sort by mutableIntStateOf(0); var dealsOnly by mutableStateOf(false); var showRange by mutableStateOf(false)
    var range by mutableStateOf<ClosedFloatingPointRange<Float>?>(null); var pending by mutableStateOf<String?>(null)
}
/** قیمت واقعی را هم‌زمان (۴ تا ۴ تا) از سایت اصلی می‌گیرد و در S.live می‌گذارد */
private suspend fun verifyOffers(list: List<Offer>) {
    val todo = list.filter { S.live[it.url] == null }
    todo.forEach { S.live[it.url] = 0L }
    val sem = Semaphore(4)
    coroutineScope {
        todo.forEach { o -> launch {
            try { sem.withPermit { S.live[o.url] = Api.verify(o) ?: -1L } }
            finally { if (S.live[o.url] == 0L) S.live.remove(o.url) }
        } }
    }
}

@Composable
private fun PriceLine(o: Offer) {
    val pct = if (o.old > o.priceToman) ((o.old - o.priceToman) * 100 / o.old).toInt() else 0
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(toman(o.priceToman), fontWeight = FontWeight.Black, color = Mint, fontSize = 13.sp, maxLines = 1, modifier = Modifier.weight(1f, false))
        if (pct > 0) Text("٪$pct", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 4.dp).clip(RoundedCornerShape(8.dp)).background(Coral).padding(horizontal = 5.dp, vertical = 1.dp))
    }
    Text(if (pct > 0) toman(o.old) else " ", color = Dim, fontSize = 10.sp, maxLines = 1, minLines = 1, textDecoration = TextDecoration.LineThrough)
}
private val FULL: LazyGridItemSpanScope.() -> GridItemSpan = { GridItemSpan(maxLineSpan) }
private fun toman(v: Long) = String.format(Locale.US, "%,d", v) + " تومان"
private fun medalOf(rank: Int) = when (rank) { 0 -> "🥇"; 1 -> "🥈"; 2 -> "🥉"; else -> "${rank + 1}" }

/** فیلتر هوشمند: حذف لوازم جانبی و نتایج نامرتبط (قیمت خیلی پایین‌تر از میانه یا نبودن کلمات جستجو در عنوان) */
private fun smartFilter(list: List<Offer>, q: String): List<Offer> {
    if (list.size < 4) return list
    val med = list.map { it.priceToman }.sorted()[list.size / 2]
    val byPrice = list.filter { it.priceToman >= med * 0.35 }
    val tokens = norm(q).split(" ", "\u200c").filter { it.length >= 2 }
    val rel = byPrice.filter { o -> val t = norm(o.title); tokens.all { it in t } }
    return if (rel.size >= 3) rel else if (byPrice.size >= 3) byPrice else list
}

@Composable
fun SearchScreen() {
    val scope = rememberCoroutineScope()
    fun go(q: String = S.query, keep: Boolean = false) {
        if (q.isBlank()) return
        S.job?.cancel()
        S.query = q; S.loading = true; S.searched = true
        if (!keep) { S.hidden = emptySet(); S.range = null; S.offers = emptyList() }
        S.failed = emptyList()
        Store.addHistory(q.trim())
        S.live.clear()
        S.job = scope.launch {
            Api.search(q.trim(), S.offline) { o, f -> S.offers = o; S.failed = f }; S.loading = false
            verifyOffers(S.offers.sortedBy { it.priceToman }.take(16))
        }
    }
    LaunchedEffect(S.pending) { S.pending?.let { S.pending = null; if (it.isNotBlank()) go(it) } }
    val adj = S.offers.map { o -> S.live[o.url]?.takeIf { it > 0 }?.let { o.copy(priceToman = it, verified = true) } ?: o }
    val base = adj.filter { it.source !in S.hidden }
    val clean = if (S.smart && !S.offline) smartFilter(base, S.query) else base
    val ranked = clean.sortedBy { it.priceToman }
    val rankOf = ranked.withIndex().associate { it.value to it.index }
    val min = ranked.firstOrNull()?.priceToman ?: 0L
    val hi = (ranked.lastOrNull()?.priceToman ?: 1L).toFloat()
    val ranged = S.range?.let { r -> ranked.filter { it.priceToman >= r.start && it.priceToman <= r.endInclusive } } ?: ranked
    val filtered = if (S.dealsOnly) ranged.filter { it.old > it.priceToman } else ranged
    val shown = when (S.sort) { 0 -> filtered; 1 -> filtered.reversed()
        else -> filtered.sortedByDescending { if (it.old > 0) (it.old - it.priceToman) * 100 / it.old else 0 } }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Spacer(Modifier.height(10.dp))
        Header(Remote.cfg.searchSubtitle.ifBlank { "هر کالایی بنویس؛ از دیجی‌کالا و ده‌ها فروشگاه ارزان‌ترین را پیدا می‌کنیم ✨" })
        OutlinedTextField(S.query, { S.query = it }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), singleLine = true,
            placeholder = { Text("مثلاً: تلویزیون، آیفون ۱۷، پلی‌استیشن ۵…", color = Dim) },
            leadingIcon = { Text("🔍", fontSize = 18.sp, modifier = Modifier.padding(start = 8.dp).clickable { go() }) },
            trailingIcon = { if (S.query.isNotEmpty()) Text("✕", color = Dim, modifier = Modifier.padding(end = 12.dp).clickable { S.query = "" }) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { go() }),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Color(0x66FFFFFF),
                focusedContainerColor = Color(0x1AFFFFFF), unfocusedContainerColor = Color(0x14FFFFFF)))
        if (S.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Pink, trackColor = Color(0x22FFFFFF))
        LazyRow(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(S.offline, { S.offline = !S.offline; if (S.query.isNotBlank()) go() }, { Text("🏬 خرید حضوری (فروشگاه‌های ترب)") }) }
            item { FilterChip(true, { S.sort = (S.sort + 1) % 3 }, { Text(listOf("⬆ ارزان به گران", "⬇ گران به ارزان", "🔥 بیشترین تخفیف")[S.sort]) }) }
            item { FilterChip(S.dealsOnly, { S.dealsOnly = !S.dealsOnly }, { Text("🏷 فقط تخفیف‌دار") }) }
            item { FilterChip(S.showRange, { S.showRange = !S.showRange; if (!S.showRange) S.range = null }, { Text("💰 بازه‌ی قیمت") }) }
            if (!S.offline) item { FilterChip(S.smart, { S.smart = !S.smart }, { Text("🧹 حذف لوازم جانبی") }) }
            items(S.offers.map { it.source }.distinct()) { src ->
                FilterChip(src !in S.hidden, { S.hidden = if (src in S.hidden) S.hidden - src else S.hidden + src }, { Text(src) })
            }
        }
        Pull(S.loading, { if (S.searched && S.query.isNotBlank()) go(S.query, keep = true) }, Modifier.fillMaxSize().padding(top = 8.dp)) {
        LazyVerticalGrid(GridCells.Fixed(2), Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!S.searched) item(span = FULL) {
                Column {
                    Text("دسته‌های پرطرفدار", Modifier.padding(top = 8.dp), fontWeight = FontWeight.Bold, color = Color.White)
                    LazyRow(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(Remote.cfg.categories.ifEmpty { listOf("📱 گوشی موبایل", "💻 لپ‌تاپ", "🎧 هدفون بلوتوث", "📺 تلویزیون", "⌚ ساعت هوشمند", "🎮 کنسول بازی", "👟 کفش ورزشی", "🧊 یخچال") }) {
                            AssistChip({ go(it.substringAfter(" ")) }, { Text(it, color = Color.White) }, shape = RoundedCornerShape(14.dp),
                                colors = AssistChipDefaults.assistChipColors(containerColor = Color(0x22FFFFFF)),
                                border = AssistChipDefaults.assistChipBorder(true, borderColor = Color(0x44FFFFFF)))
                        }
                    }
                    if (Store.history.isNotEmpty()) {
                        Row(Modifier.padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("جستجوهای اخیر", Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Color.White)
                            TextButton({ Store.clearHistory() }) { Text("پاک کردن", color = Pink) }
                        }
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(Store.history.toList()) {
                            SuggestionChip({ go(it) }, { Text("🕘 $it", color = Color.White) }, shape = RoundedCornerShape(14.dp)) } }
                    }
                }
            }
            if (S.failed.isNotEmpty() && !S.loading) item(span = FULL) {
                Column {
                    Text("پاسخ نداد: " + S.failed.joinToString("، "), color = Coral, fontSize = 12.sp)
                    Text("اگر فیلترشکن روشن است خاموشش کنید؛ بعضی فروشگاه‌ها IP خارج از ایران را رد می‌کنند.", color = Dim, fontSize = 11.sp)
                }
            }
            if (S.searched && clean.isEmpty() && !S.loading) item(span = FULL) {
                Text(if (S.offline) "فروشگاه حضوری‌ای برای این کالا در ترب پیدا نشد." else "نتیجه‌ای پیدا نشد؛ اینترنت یا کلمه‌ی جستجو را بررسی کنید.", color = Dim)
            }
            if (clean.isNotEmpty()) item(span = FULL) {
                val ps = clean.map { it.priceToman }; val max = ps.max(); val avg = ps.average().toLong(); val save = if (max > 0) (max - min) * 100 / max else 0
                GlassCard(Modifier.fillMaxWidth(), glow = true) {
                    Text("خلاصه‌ی بازار • ${ps.size} پیشنهاد از ${clean.map { it.shop.ifBlank { it.source } }.distinct().size} فروشگاه", fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    Row { Column(Modifier.weight(1f)) { Text("ارزان‌ترین", color = Dim, fontSize = 11.sp); Text(toman(min), color = Mint, fontWeight = FontWeight.Black, fontSize = 15.sp) }
                          Column(Modifier.weight(1f)) { Text("میانگین", color = Dim, fontSize = 11.sp); Text(toman(avg), color = Color.White, fontSize = 13.sp) }
                          Column(Modifier.weight(1f)) { Text("گران‌ترین", color = Dim, fontSize = 11.sp); Text(toman(max), color = Coral, fontSize = 13.sp) } }
                    Text("💡 خرید از ارزان‌ترین تا $save٪ صرفه‌جویی دارد (${toman(max - min)})", color = Amber, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
            if (S.showRange && ranked.size > 1) item(span = FULL) {
                val r = S.range ?: (min.toFloat()..hi)
                GlassCard(Modifier.fillMaxWidth()) {
                    Text("از ${toman(r.start.toLong())} تا ${toman(r.endInclusive.toLong())}", color = Color.White, fontSize = 12.sp)
                    RangeSlider(r, { S.range = it }, valueRange = min.toFloat()..hi)
                }
            }
            gridItemsIndexed(shown) { i, o ->
                val rank = rankOf[o] ?: i
                ProductCard(o, rank, min) { S.detail = o }
            }
            item(span = FULL) { Spacer(Modifier.height(10.dp)) }
        }
        }
    }
    S.detail?.let { DetailSheet(it, S.offers) { S.detail = null } }
}

/** کارت مربعی هم‌اندازه: عکس بالا، متن پایین */
@Composable
fun ProductCard(o: Offer, rank: Int, min: Long, onClick: () -> Unit) {
    val diff = if (min > 0) (o.priceToman - min) * 100 / min else 0
    GlassCard(Modifier.fillMaxWidth(), glow = rank == 0, onClick = onClick) {
        Box {
            Img(o.image, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(14.dp)).background(Color.White))
            Text(medalOf(rank), fontSize = if (rank < 3) 24.sp else 13.sp, color = Color.White, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopStart).padding(4.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x99070B1E)).padding(horizontal = 7.dp, vertical = 2.dp))
            FavStar(o, Modifier.align(Alignment.TopEnd).padding(4.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(o.title, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = Color.White)
        Spacer(Modifier.height(4.dp))
        SourceChip(o.source)
        Text(if (o.offline) "🏬 " + listOf(o.shop, o.city).filter { it.isNotBlank() }.joinToString(" • ") else o.shop.ifBlank { " " },
            color = Dim, fontSize = 11.sp, maxLines = 1, minLines = 1, overflow = TextOverflow.Ellipsis)
        PriceLine(o)
        Text(when { (S.live[o.url] ?: 0L) > 0 -> "✅ قیمت سایت اصلی"; S.live[o.url] == -1L -> "⚠ تأیید نشد"; S.live[o.url] == 0L -> "⏳ بررسی…"; else -> " " },
            fontSize = 10.sp, color = Dim, maxLines = 1, minLines = 1)
        Text(if (diff in 1..999) "+$diff٪ از ارزان‌ترین" else if (rank == 0) "👑 بهترین پیشنهاد" else " ",
            color = if (rank == 0) Amber else Coral, fontSize = 11.sp, maxLines = 1, minLines = 1)
    }
}

/** صفحه‌ی محصول: عکس بزرگ + رتبه‌بندی فروشگاه‌ها (مدال طلا/نقره/برنز) از ارزان به گران.
 *  لینک‌های خراب (۴۰۴) پنهان می‌شوند و اگر چیزی نماند همیشه یک راه جایگزین (ترب) نشان داده می‌شود. */
@Composable
fun DetailSheet(o: Offer, pool: List<Offer>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var list by remember(o) { mutableStateOf<List<Offer>?>(null) }
    var attempt by remember(o) { mutableIntStateOf(0) }
    var onlyOffline by remember(o) { mutableStateOf(S.offline) }
    LaunchedEffect(o, attempt) {
        list = null
        list = Api.sellersFor(o, pool).map { it.copy(url = Links.clean(it.url, it.source)) }.filter { it.url.isNotEmpty() }
    }
    LaunchedEffect(list) { list?.let { verifyOffers(it.sortedBy { r -> r.priceToman }.take(12)) } }
    LaunchedEffect(list) {
        list?.let { l ->
            val sem = Semaphore(4)
            coroutineScope {
                l.sortedBy { it.priceToman }.take(15).forEach { r ->
                    if (S.alive[r.url] == null) launch { sem.withPermit { S.alive[r.url] = Api.alive(r.url) } }
                }
            }
        }
    }
    val good = list?.filter { S.alive[it.url] != false }
    val dead = (list?.size ?: 0) - (good?.size ?: 0)
    val eff = good?.map { r -> S.live[r.url]?.takeIf { it > 0 }?.let { r.copy(priceToman = it, verified = true) } ?: r }?.sortedBy { it.priceToman }
    val rows = eff?.let { l -> if (onlyOffline) l.filter { it.offline } else l }
    ModalBottomSheet(onClose, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = Bg) {
        LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Box {
                    Img(o.image, Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(16.dp)).background(Color.White))
                    FavStar(o, Modifier.align(Alignment.TopEnd).padding(8.dp), 26.sp)
                }
                Text(o.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp))
                Text("فروشگاه‌ها از ارزان به گران", color = Dim, fontSize = 12.sp)
                if (list?.any { it.offline } == true)
                    FilterChip(onlyOffline, { onlyOffline = !onlyOffline }, { Text("🏬 فقط حضوری") }, modifier = Modifier.padding(top = 4.dp))
                if (rows == null) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Pink)
            }
            gridOrList(rows.orEmpty(), ctx)
            if (rows != null) {
                if (rows.isEmpty()) item {
                    Column {
                        Text("فروشنده‌ی قابل‌ارائه‌ای برای این کالا پیدا نشد.", color = Coral, fontSize = 13.sp)
                        TextButton({ attempt++ }, contentPadding = PaddingValues(0.dp)) { Text("🔄 تلاش دوباره", color = Cyan) }
                    }
                }
                if (dead > 0) item { Text("$dead لینک خراب (صفحه‌ی حذف‌شده) پنهان شد", color = Dim, fontSize = 11.sp) }
                item {
                    GlassCard(Modifier.fillMaxWidth(), onClick = { Links.open(ctx, o.copy(url = if (o.key.isNotBlank()) Links.torobPage(o.key) else Links.torobSearch(o.title))) }) {
                        Text("🔎 دیدن همین کالا در ترب", color = Color.White, fontSize = 13.sp)
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.gridOrList(rows: List<Offer>, ctx: Context) {
    itemsIndexed(rows) { i, r ->
        GlassCard(Modifier.fillMaxWidth(), glow = i == 0, onClick = { Links.open(ctx, r) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(medalOf(i), fontSize = if (i < 3) 28.sp else 16.sp, modifier = Modifier.width(42.dp), color = Color.White)
                Column(Modifier.weight(1f)) {
                    Text(if (r.agg) "مشاهده در ترب" + (if (r.shop.isNotBlank()) " (${r.shop})" else "") else r.shop.ifBlank { r.source },
                        color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SourceChip(r.source)
                        if (r.offline) Text("  🏬 حضوری ${r.city}", color = Amber, fontSize = 11.sp)
                    }
                }
                Text((if (r.verified) "✅ " else "") + toman(r.priceToman), fontWeight = FontWeight.Black, color = Mint, fontSize = 14.sp)
                Spacer(Modifier.width(8.dp))
                FavStar(r, size = 20.sp)
            }
        }
    }
}

@Composable
fun SourceChip(name: String) {
    val b = when (name) {
        "دیجی‌کالا" -> listOf(Color(0xFFFF4D6D), Color(0xFFEF394E)); "باسلام" -> listOf(Color(0xFF00D4B4), Color(0xFF00A88F))
        "ترب", "ترب (حضوری)" -> listOf(Color(0xFF38BDF8), Color(0xFF2563EB))
        else -> { val h = (name.hashCode() and 0xFFFF) % 360f; listOf(Color.hsv(h, .55f, .85f), Color.hsv((h + 30) % 360f, .65f, .7f)) }
    }
    Box(Modifier.clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(b)).padding(horizontal = 10.dp, vertical = 2.dp)) {
        Text(name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun FavsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var refreshing by remember { mutableStateOf(false) }
    Pull(refreshing, {
        refreshing = true
        scope.launch { try { Store.refreshPrices() } finally { refreshing = false } }
    }) {
        LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Header("پیشنهادهای نشان‌شده‌ی شما ⭐")
                if (Store.favs.isEmpty()) Text("هنوز چیزی نشان نکرده‌اید. روی ☆ کنار هر محصول بزنید.", color = Dim, modifier = Modifier.padding(top = 8.dp))
                else Text("برای به‌روزشدن قیمت‌ها صفحه را به پایین بکشید", color = Dim, fontSize = 11.sp)
            }
            items(Store.favs.toList()) { o ->
                GlassCard(Modifier.fillMaxWidth(), onClick = { S.detail = o }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(o.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, color = Color.White); Spacer(Modifier.height(5.dp)); SourceChip(o.source) }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(toman(o.priceToman), color = Mint, fontWeight = FontWeight.Black, fontSize = 14.sp)
                            Row { Text("📤", fontSize = 22.sp, modifier = Modifier.clickable {
                                ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                                    .putExtra(Intent.EXTRA_TEXT, "${o.title}\n${toman(o.priceToman)} — ${o.source}\n${Links.candidates(o).firstOrNull().orEmpty()}"), null)) })
                                Spacer(Modifier.width(14.dp)); Text("🗑", fontSize = 22.sp, modifier = Modifier.clickable { Store.toggleFav(o) }) }
                        }
                    }
                }
            }
        }
    }
    S.detail?.let { DetailSheet(it, Store.favs.toList()) { S.detail = null } }
}

@Composable
fun HomeScreen(onSearch: (String) -> Unit) {
    var secs by remember { mutableStateOf<List<HomeSec>>(emptyList()) }
    var round by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var failed by remember { mutableStateOf(false) }
    val ticker = Mkt.secs[0]?.items.orEmpty().take(6)
    val cats = remember(round, Remote.cfg.categories) { Remote.cfg.categories.ifEmpty { listOf("📱 گوشی موبایل", "💻 لپ‌تاپ", "📺 تلویزیون", "🎮 کنسول بازی", "🎧 هدفون", "⌚ ساعت هوشمند", "🧊 یخچال", "👟 کفش ورزشی", "📷 دوربین", "🚲 دوچرخه") }.shuffled() }
    // ویترین قبلی تا رسیدن اولین بخش تازه روی صفحه می‌ماند (صفحه خالی و پرش نداریم)
    LaunchedEffect(round) {
        loading = true; failed = false
        launch { Remote.refresh() }
        var first = true
        Api.home { s -> if (first) { first = false; secs = listOf(s) } else secs = (secs + s).sortedBy { it.order } }
        loading = false
        if (first) failed = true
    }
    Pull(loading, { loading = true; Mkt.kick(); round++ }) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Header(Remote.cfg.homeSubtitle.ifBlank { "هر بار یک ویترین تازه از دیجی‌کالا، ترب و باسلام ✨" })
            GlassCard(Modifier.fillMaxWidth(), onClick = { onSearch("") }) { Text("🔍  جستجوی هر کالا و مقایسه‌ی قیمت…", color = Dim) }
        }
        if (Remote.cfg.announcement.isNotBlank()) item {
            val au = Remote.cfg.announcementUrl; val ctx = LocalContext.current
            GlassCard(Modifier.fillMaxWidth(), glow = true, onClick = if (au.isNotBlank()) ({ Links.openUrl(ctx, au) }) else null) {
                Text("📢 " + Remote.cfg.announcement, color = Color.White, fontSize = 13.sp)
            }
        }
        if (ticker.isNotEmpty()) item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(ticker) { q ->
                Row(Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0x22FFFFFF)).padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(q.icon + " " + q.name.substringBefore(" ("), color = Dim, fontSize = 11.sp); Spacer(Modifier.width(6.dp))
                    Text(q.value.removeSuffix(" تومان"), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    q.change?.let { Text((if (it >= 0) " ▲" else " ▼"), color = if (it >= 0) Mint else Coral, fontSize = 10.sp) }
                } } }
        }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(cats) { c ->
            AssistChip({ onSearch(c.substringAfter(" ")) }, { Text(c, color = Color.White) }, shape = RoundedCornerShape(14.dp),
                colors = AssistChipDefaults.assistChipColors(containerColor = Color(0x22FFFFFF))) } } }
        if (failed && secs.isEmpty()) item {
            Text("اتصال برقرار نشد. اینترنت را بررسی کنید و صفحه را به پایین بکشید.", color = Coral, fontSize = 13.sp)
        }
        (Remote.cfg.sections + secs).forEach { sec ->
            item {
                if (sec.big) {
                    val o = sec.items.first()
                    GlassCard(Modifier.fillMaxWidth(), glow = true, onClick = { S.detail = o }) {
                        Text(sec.title, fontWeight = FontWeight.Black, color = Amber)
                        Spacer(Modifier.height(8.dp))
                        Row {
                            Box {
                                Img(o.image, Modifier.size(130.dp).clip(RoundedCornerShape(14.dp)).background(Color.White))
                                FavStar(o, Modifier.align(Alignment.TopEnd).padding(4.dp), 18.sp)
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(o.title, color = Color.White, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(4.dp)); SourceChip(o.source); PriceLine(o)
                                TextButton({ loading = true; round++ }, contentPadding = PaddingValues(0.dp)) { Text("🎲 یکی دیگه", color = Pink) }
                            }
                        }
                    }
                } else {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(sec.title, Modifier.weight(1f), style = TextStyle(brush = Brand, fontSize = 16.sp, fontWeight = FontWeight.Black))
                            if (sec.q.isNotBlank()) TextButton({ onSearch(sec.q) }) { Text("بیشتر ‹", color = Cyan) }
                        }
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) { items(sec.items) { o ->
                            GlassCard(Modifier.width(150.dp), onClick = { S.detail = o }) {
                                Box {
                                    Img(o.image, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(Color.White))
                                    FavStar(o, Modifier.align(Alignment.TopEnd).padding(3.dp), 16.sp)
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(o.title, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = Color.White)
                                PriceLine(o)
                            } } }
                    }
                }
            }
        }
        item {
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Pink, trackColor = Color(0x22FFFFFF))
            else Button({ loading = true; round++ }, Modifier.fillMaxWidth()) { Text("🔄 ویترین تازه") }
        }
    }
    }
    S.detail?.let { DetailSheet(it, (Remote.cfg.sections + secs).flatMap { s -> s.items }) { S.detail = null } }
}

private fun numFmt(v: Double) = String.format(Locale.US, if (v < 100) "%,.2f" else "%,.0f", v)

@Composable
fun PriceRow(q: Quote, expanded: Boolean, onClick: () -> Unit) {
    val up = (q.change ?: 0.0) >= 0
    GlassCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0x22FFFFFF)), Alignment.Center) {
                if (q.logo.isNotBlank()) Img(q.logo, Modifier.size(32.dp), fallback = q.name.take(1)) else Text(q.icon.ifBlank { q.name.take(1) }, fontSize = 22.sp)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(q.name, fontSize = 13.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                q.change?.let { Text((if (it >= 0) "▲ " else "▼ ") + String.format(Locale.US, "%.2f%%", Math.abs(it)), fontSize = 12.sp, color = if (up) Mint else Coral) }
            }
            Spark(q.spark, up, Modifier.width(64.dp).height(30.dp))
            Spacer(Modifier.width(8.dp))
            Text(q.value, fontWeight = FontWeight.Black, fontSize = 13.sp, color = Color.White)
        }
        if (expanded) {
            if (q.spark.size >= 2) {
                Spark(q.spark, up, Modifier.fillMaxWidth().height(120.dp).padding(top = 8.dp))
                Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                    Text("کمترین ${numFmt(q.spark.min())}", Modifier.weight(1f), color = Coral, fontSize = 11.sp)
                    Text("بیشترین ${numFmt(q.spark.max())}", color = Mint, fontSize = 11.sp)
                }
            } else Text("نمودار پس از چند به‌روزرسانی ساخته می‌شود.", color = Dim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
fun PricesScreen() {
    var mode by remember { mutableIntStateOf(0) }
    // صرافی‌ها فقط وقتی همین تب باز است هر ۵ ثانیه پرسیده می‌شوند
    DisposableEffect(mode) { Mkt.setExchangesVisible(mode == 1); onDispose { Mkt.setExchangesVisible(false) } }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(start = 14.dp, end = 14.dp, top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(mode == 0, { mode = 0 }, { Text("📊 بازار") })
            FilterChip(mode == 1, { mode = 1 }, { Text("🏦 بیت‌پین / رمزینکس ⚡ ۵ ثانیه") })
        }
        Pull(Mkt.refreshing, { scope.launch { Mkt.refreshNow() } }) {
            if (mode == 0) MarketPrices() else ExchangesScreen()
        }
    }
}

private fun ageText(now: Long, at: Long) = if (at == 0L) "" else "${maxOf(0L, (now - at) / 1000)} ثانیه پیش"

@Composable
fun MarketPrices() {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var open by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Header("طلا، ارز و رمزارز • زنده ⚡")
            Text("روی هر ردیف بزنید تا نمودار بزرگ شود • برای تازه‌سازی همین‌حالا صفحه را به پایین بکشید", fontSize = 12.sp, color = Dim)
            if (Mkt.secs.isEmpty()) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Pink, trackColor = Color(0x22FFFFFF))
        }
        for (i in 0..2) Mkt.secs[i]?.let { s ->
            item {
                val bad = Mkt.failed[i] == true
                Column(Modifier.padding(top = 12.dp)) {
                    Text(s.title, style = TextStyle(brush = Brand, fontSize = 16.sp, fontWeight = FontWeight.Black))
                    Text(if (bad) "⚠ بروزرسانی ناموفق؛ قیمت‌های ${ageText(now, s.at)} نمایش داده می‌شود" else "🟢 بروز شده ${ageText(now, s.at)} • هر ${if (i == 2) 20 else 10} ثانیه",
                        fontSize = 11.sp, color = if (bad) Coral else Dim)
                }
            }
            items(s.items) { q -> PriceRow(q, open == q.id) { open = if (open == q.id) null else q.id } }
        }
        item { Spacer(Modifier.height(10.dp)) }
    }
}

@Composable
fun ExchangesScreen() {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Header("قیمت زنده‌ی صرافی‌ها • هر ۵ ثانیه ⚡")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(Mkt.exNames) { name ->
                val t = Mkt.exAt[name]; val age = if (t == null) -1L else (now - t) / 1000
                val col = when { t == null && Mkt.exBad[name] == true -> Coral; t == null -> Dim; Mkt.exBad[name] == true || age > 12 -> Amber; else -> Mint }
                Row(Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0x22FFFFFF)).padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(col)); Spacer(Modifier.width(6.dp))
                    Text(name + if (age >= 0) " • ${age}ث" else if (Mkt.exBad[name] == true) " • پاسخ نداد" else " • …", color = Color.White, fontSize = 12.sp)
                } } }
            Text("قیمت‌ها به تومان؛ سبز = آخرین تغییر افزایشی، قرمز = کاهشی • برای تازه‌سازی فوری صفحه را به پایین بکشید", color = Dim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }
        items(Api.coins) { (sym, fa) ->
            val rows = Mkt.exNames.mapNotNull { n -> Mkt.ex[n]?.get(sym)?.let { n to it } }
            if (rows.isNotEmpty()) GlassCard(Modifier.fillMaxWidth()) {
                val lo = rows.minOf { it.second.price }; val hiP = rows.maxOf { it.second.price }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0x22FFFFFF)), Alignment.Center) { Img(Api.logo(sym), Modifier.size(26.dp), fallback = sym.take(1).uppercase()) }
                    Spacer(Modifier.width(8.dp))
                    Text("$fa (${sym.uppercase()})", Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    if (rows.size > 1 && lo > 0) Text("اختلاف ${String.format(Locale.US, "%.2f", (hiP - lo) / lo * 100)}٪", color = Amber, fontSize = 11.sp)
                }
                Spacer(Modifier.height(6.dp))
                rows.forEach { (n, t) ->
                    val d = Mkt.exDir[n + sym] ?: 0
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(n + if (rows.size > 1 && t.price == lo) "  ✅ ارزان‌ترین" else "", Modifier.weight(1f), color = Dim, fontSize = 12.sp)
                        t.change?.let { Text((if (it >= 0) "▲" else "▼") + String.format(Locale.US, "%.1f%%  ", Math.abs(it)), color = if (it >= 0) Mint else Coral, fontSize = 10.sp) }
                        Text(numFmt(t.price), color = when (d) { 1 -> Mint; -1 -> Coral; else -> Color.White }, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(10.dp)) }
    }
}
