package ir.pricefinder

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

val Bg = Color(0xFF070B1E); val Cyan = Color(0xFF22D3EE); val Violet = Color(0xFFA78BFA)
val Pink = Color(0xFFF472B6); val Amber = Color(0xFFFBBF24); val Mint = Color(0xFF34D399)
val Coral = Color(0xFFFB7185); val Dim = Color(0xFFA9B4D6)
val Brand = Brush.linearGradient(listOf(Cyan, Violet, Pink))

/** پس‌زمینه‌ی متحرک: کره‌های نورانی رنگی + ذرات درخشان */
@Composable
fun AnimatedBackground() {
    val t by rememberInfiniteTransition(label = "bg").animateFloat(
        0f, (2 * Math.PI).toFloat(), infiniteRepeatable(tween(26000, easing = LinearEasing)), label = "t")
    Canvas(Modifier.fillMaxSize().background(Bg)) {
        val w = size.width; val h = size.height
        fun orb(c: Color, fx: Float, fy: Float, px: Float, py: Float, r: Float) {
            val o = Offset(w * (fx + 0.25f * sin(t + px)), h * (fy + 0.18f * cos(t * 0.8f + py)))
            drawCircle(Brush.radialGradient(listOf(c.copy(alpha = 0.5f), Color.Transparent), o, r), r, o)
        }
        orb(Cyan, .15f, .12f, 0f, 1f, w * .85f); orb(Violet, .9f, .35f, 2f, 0f, w * .95f)
        orb(Pink, .25f, .72f, 4f, 2f, w * .9f); orb(Amber, .95f, .98f, 1f, 3f, w * .65f)
        for (i in 0 until 30) {
            val seed = i * 37.7f
            val x = w * (sin(seed) * 0.5f + 0.5f)
            val y = h * (1f - ((t / 6.283f) * (0.3f + (i % 5) * 0.15f) + i / 30f) % 1f)
            drawCircle(Color.White.copy(alpha = 0.2f + 0.6f * abs(sin(t * 2 + seed))), 1.5f + (i % 3) * 1.2f, Offset(x, y))
        }
        drawRect(Brush.verticalGradient(listOf(Color(0x55070B1E), Color(0x99070B1E))))
    }
}

/** لوگوی قیمت‌یاب: ذره‌بین با جرقه‌ی قیمت روی پس‌زمینه‌ی گرادیانی و براق */
@Composable
fun Logo(size: Dp = 54.dp) {
    val s by rememberInfiniteTransition(label = "logo").animateFloat(
        -0.6f, 1.4f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "s")
    Canvas(Modifier.size(size)) {
        val r = this.size.minDimension
        val shape = Path().apply { addRoundRect(RoundRect(0f, 0f, r, r, CornerRadius(r * .3f))) }
        drawPath(shape, Brand)
        val c = Offset(r * .44f, r * .44f)
        drawCircle(Color.White, r * .24f, c, style = Stroke(r * .075f))
        drawLine(Color.White, Offset(r * .62f, r * .62f), Offset(r * .83f, r * .83f), r * .1f, StrokeCap.Round)
        val k = r * .13f
        drawPath(Path().apply {
            moveTo(c.x, c.y - k); quadraticBezierTo(c.x, c.y, c.x + k, c.y); quadraticBezierTo(c.x, c.y, c.x, c.y + k)
            quadraticBezierTo(c.x, c.y, c.x - k, c.y); quadraticBezierTo(c.x, c.y, c.x, c.y - k); close()
        }, Amber)
        clipPath(shape) {
            drawRect(Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = .4f), Color.Transparent),
                Offset(r * s, 0f), Offset(r * s + r * .35f, r)))
        }
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, glow: Boolean = false, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val sh = RoundedCornerShape(22.dp)
    var m: Modifier
    m = modifier.clip(sh)
        .background(Brush.linearGradient(listOf(Color(0x2EFFFFFF), Color(0x10FFFFFF))))
        .border(if (glow) 1.5.dp else 1.dp, if (glow) Brand else Brush.linearGradient(listOf(Color(0x66FFFFFF), Color(0x11FFFFFF))), sh)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(14.dp), content = content)
}


/** عکس مقاوم: هدر مرجع و User-Agent (در MainActivity)، تلاش مجدد خودکار تا ۳ بار، و لمس برای تلاش دوباره */
@Composable
fun Img(url: String, modifier: Modifier = Modifier, fit: ContentScale = ContentScale.Fit, fallback: String = "🖼") {
    val ctx = LocalContext.current
    var key by remember(url) { mutableIntStateOf(0) }
    var auto by remember(url) { mutableIntStateOf(0) }
    val u = when { url.startsWith("//") -> "https:$url"; url.startsWith("http://") -> "https://" + url.removePrefix("http://"); else -> url }
    if (u.isBlank()) { Box(modifier, Alignment.Center) { Text(fallback, fontSize = 22.sp) }; return }
    SubcomposeAsyncImage(
        model = ImageRequest.Builder(ctx).data(u).memoryCacheKey("$u#$key").diskCacheKey(u).crossfade(true).build(),
        contentDescription = null, modifier = modifier, contentScale = fit,
        loading = { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Cyan) } },
        error = {
            LaunchedEffect(key) { if (auto < 3) { delay(900L * (auto + 1)); auto++; key++ } }
            Box(Modifier.fillMaxSize().clickable { key++ }, Alignment.Center) { Text(if (auto < 3) "⏳" else "🔄", fontSize = 22.sp) }
        }
    )
}

/** نمودار خطی کوچک (اسپارک‌لاین) */
@Composable
fun Spark(v: List<Double>, up: Boolean, modifier: Modifier = Modifier) {
    if (v.size < 2) { Spacer(modifier); return }
    val col = if (up) Mint else Coral
    Canvas(modifier) {
        val mn = v.min(); val r = (v.max() - mn).takeIf { it > 0 } ?: 1.0
        val path = Path(); val fill = Path()
        v.forEachIndexed { i, x ->
            val px = size.width * i / (v.size - 1); val py = size.height * (1f - ((x - mn) / r).toFloat()) * 0.9f + size.height * 0.05f
            if (i == 0) { path.moveTo(px, py); fill.moveTo(px, size.height); fill.lineTo(px, py) } else { path.lineTo(px, py); fill.lineTo(px, py) }
        }
        fill.lineTo(size.width, size.height); fill.close()
        drawPath(fill, Brush.verticalGradient(listOf(col.copy(.35f), Color.Transparent)))
        drawPath(path, col, style = Stroke(width = 3f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
