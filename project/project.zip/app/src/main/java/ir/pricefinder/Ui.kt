package ir.pricefinder

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

val Bg = Color(0xFF070B1E); val Cyan = Color(0xFF22D3EE); val Violet = Color(0xFFA78BFA)
val Pink = Color(0xFFF472B6); val Amber = Color(0xFFFBBF24); val Mint = Color(0xFF34D399)
val Coral = Color(0xFFFB7185); val Dim = Color(0xFFA9B4D6)
val Brand = Brush.linearGradient(listOf(Cyan, Violet, Pink))

/** پس‌زمینه‌ی متحرک: کره‌های نورانی رنگی + ذرات درخشان */
@Composable
fun AnimatedBackground() {
    val t by rememberInfiniteTransition(label = "bg").animateFloat(
        0f, (2 * Math.PI).toFloat(), infiniteRepeatable(tween(26000, easing = LinearEasing)), label = "t")
    Canvas(Modifier.fillMaxSize().background(Bg)) {
        val w = size.width; val h = size.height
        fun orb(c: Color, fx: Float, fy: Float, px: Float, py: Float, r: Float) {
            val o = Offset(w * (fx + 0.25f * sin(t + px)), h * (fy + 0.18f * cos(t * 0.8f + py)))
            drawCircle(Brush.radialGradient(listOf(c.copy(alpha = 0.5f), Color.Transparent), o, r), r, o)
        }
        orb(Cyan, .15f, .12f, 0f, 1f, w * .85f); orb(Violet, .9f, .35f, 2f, 0f, w * .95f)
        orb(Pink, .25f, .72f, 4f, 2f, w * .9f); orb(Amber, .95f, .98f, 1f, 3f, w * .65f)
        for (i in 0 until 30) {
            val seed = i * 37.7f
            val x = w * (sin(seed) * 0.5f + 0.5f)
            val y = h * (1f - ((t / 6.283f) * (0.3f + (i % 5) * 0.15f) + i / 30f) % 1f)
            drawCircle(Color.White.copy(alpha = 0.2f + 0.6f * abs(sin(t * 2 + seed))), 1.5f + (i % 3) * 1.2f, Offset(x, y))
        }
        drawRect(Brush.verticalGradient(listOf(Color(0x55070B1E), Color(0x99070B1E))))
    }
}

/** لوگوی قیمت‌یاب: ذره‌بین با جرقه‌ی قیمت روی پس‌زمینه‌ی گرادیانی و براق */
@Composable
fun Logo(size: Dp = 54.dp) {
    val s by rememberInfiniteTransition(label = "logo").animateFloat(
        -0.6f, 1.4f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "s")
    Canvas(Modifier.size(size)) {
        val r = this.size.minDimension
        val shape = Path().apply { addRoundRect(RoundRect(0f, 0f, r, r, CornerRadius(r * .3f))) }
        drawPath(shape, Brand)
        val c = Offset(r * .44f, r * .44f)
        drawCircle(Color.White, r * .24f, c, style = Stroke(r * .075f))
        drawLine(Color.White, Offset(r * .62f, r * .62f), Offset(r * .83f, r * .83f), r * .1f, StrokeCap.Round)
        val k = r * .13f
        drawPath(Path().apply {
            moveTo(c.x, c.y - k); quadraticBezierTo(c.x, c.y, c.x + k, c.y); quadraticBezierTo(c.x, c.y, c.x, c.y + k)
            quadraticBezierTo(c.x, c.y, c.x - k, c.y); quadraticBezierTo(c.x, c.y, c.x, c.y - k); close()
        }, Amber)
        clipPath(shape) {
            drawRect(Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = .4f), Color.Transparent),
                Offset(r * s, 0f), Offset(r * s + r * .35f, r)))
        }
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, glow: Boolean = false, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val sh = RoundedCornerShape(22.dp)
    var m: Modifier
    m = modifier.clip(sh)
        .background(Brush.linearGradient(listOf(Color(0x2EFFFFFF), Color(0x10FFFFFF))))
        .border(if (glow) 1.5.dp else 1.dp, if (glow) Brand else Brush.linearGradient(listOf(Color(0x66FFFFFF), Color(0x11FFFFFF))), sh)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(14.dp), content = content)
}
