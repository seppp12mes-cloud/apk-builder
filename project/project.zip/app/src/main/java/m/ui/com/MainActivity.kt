package m.ui.com

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var botBg: View
    private lateinit var insetsCtl: WindowInsetsControllerCompat
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooserLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        val uris: Array<Uri>? = if (result.resultCode == android.app.Activity.RESULT_OK && data != null) {
            WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
        } else null
        filePathCallback?.onReceiveValue(uris)
        filePathCallback = null
    }

    // رنگ ناحیه‌ی زیر اپ (پشت نوار ناوبری سیستم) را با منوی پایین صفحه هماهنگ می‌کند.
    private val navColorTick = object : Runnable {
        override fun run() {
            applyNavColor()
            webView.postDelayed(this, 1500)
        }
    }

    // پل جاوااسکریپت ← اندروید: navigator.share در WebView وجود ندارد، پس اشتراک‌گذاری و لرزش از اینجا انجام می‌شود.
    inner class AppBridge {
        @JavascriptInterface
        fun share(title: String?, url: String?) {
            runOnUiThread {
                val text = listOf(title ?: "", url ?: "").filter { it.isNotBlank() }.joinToString("\n")
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                try {
                    startActivity(Intent.createChooser(send, title ?: ""))
                } catch (e: Exception) {
                    // برنامه‌ای برای دریافت متن نصب نیست
                }
            }
        }

        @Suppress("DEPRECATION")
        @JavascriptInterface
        fun vibrate(ms: Int) {
            try {
                val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
                val d = ms.coerceIn(1, 500).toLong()
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(d, VibrationEffect.DEFAULT_AMPLITUDE))
                else v.vibrate(d)
            } catch (e: Exception) {
                // دستگاه لرزاننده ندارد یا مجوز داده نشده
            }
        }
    }

    // لینک‌های tel: ، mailto: ، sms: ، geo: ، whatsapp: ، https://wa.me و ... همیشه بیرون از WebView باز می‌شوند.
    private fun openExternal(uri: Uri) {
        try {
            if (uri.scheme == "intent") {
                startActivity(Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME))
            } else {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            }
        } catch (e: Exception) {
            // هیچ برنامه‌ای برای این لینک نصب نیست
        }
    }

    private fun applyNavColor() {
        val js = "(function(){var n=document.querySelector('nav');var f=n&&parseFloat(getComputedStyle(n).left)>0;var e=(n&&!f)?n:document.body;var c=getComputedStyle(e).backgroundColor;if(c.indexOf('rgba')===0&&parseFloat(c.split(',')[3])===0){c=getComputedStyle(document.body).backgroundColor}if(c.indexOf('rgba')===0&&parseFloat(c.split(',')[3])===0){c=''}return c})()"
        webView.evaluateJavascript(js) { raw ->
            val n = (raw ?: "").filter { it.isDigit() || it == ',' }.split(",").mapNotNull { it.toIntOrNull() }
            if (n.size >= 3) {
                botBg.setBackgroundColor(Color.rgb(n[0], n[1], n[2]))
                insetsCtl.isAppearanceLightNavigationBars = (0.299 * n[0] + 0.587 * n[1] + 0.114 * n[2]) / 255 > 0.6
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // از اندروید ۱۵ به بعد پنجره همیشه تمام‌صفحه (edge-to-edge) است؛ فاصله‌ی نوار وضعیت و نوار ناوبری را خودمان رعایت می‌کنیم.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        setContentView(R.layout.activity_main)

        val root = findViewById<View>(R.id.root)
        val topBg = findViewById<View>(R.id.topbg)
        botBg = findViewById(R.id.botbg)
        webView = findViewById(R.id.webview)

        val bar = Color.parseColor("#7dd3ff")
        root.setBackgroundColor(bar)
        topBg.setBackgroundColor(bar)
        botBg.setBackgroundColor(Color.WHITE)
        insetsCtl = WindowCompat.getInsetsController(window, root)
        insetsCtl.isAppearanceLightStatusBars = true
        insetsCtl.isAppearanceLightNavigationBars = true

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val imeOpen = ime.bottom > 0
            val bottom = if (imeOpen) ime.bottom else bars.bottom
            val lp = webView.layoutParams as ViewGroup.MarginLayoutParams
            lp.setMargins(bars.left, bars.top, bars.right, bottom)
            webView.layoutParams = lp
            topBg.layoutParams.height = bars.top
            topBg.requestLayout()
            botBg.layoutParams.height = if (imeOpen) 0 else bars.bottom
            botBg.requestLayout()
            insets
        }

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.setSupportMultipleWindows(true)
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.addJavascriptInterface(AppBridge(), "AndroidApp")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false
                val scheme = request.url.scheme ?: ""
                if (scheme == "file" || scheme == "about" || scheme == "data" || scheme == "blob" || scheme == "javascript") return false
                openExternal(request.url)
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
                applyNavColor()
            }
        }

        // بدون WebChromeClient، alert / confirm / prompt و انتخاب فایل کار نمی‌کند؛ target=_blank و window.open هم اینجا مدیریت می‌شوند.
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: WebChromeClient.FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                return try {
                    fileChooserLauncher.launch(params.createIntent())
                    true
                } catch (e: ActivityNotFoundException) {
                    filePathCallback = null
                    false
                }
            }

            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val tmp = WebView(view.context)
                tmp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                        openExternal(request.url)
                        v.post { v.destroy() }
                        return true
                    }
                }
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = tmp
                resultMsg.sendToTarget()
                return true
            }
        }

        // دانلودهای http(s) به مرورگر / مدیر دانلود سیستم داده می‌شوند.
        webView.setDownloadListener { url, _, _, _, _ ->
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (e: Exception) {
                // لینک‌های blob: و data: را نمی‌شود بیرون باز کرد
            }
        }

        webView.loadUrl("file:///android_asset/index.html")
        webView.postDelayed(navColorTick, 800)

        // جایگزین مدرن onBackPressed() — با اشاره‌ی بازگشت پیش‌بینانه‌ی اندروید ۱۳+ هم درست کار می‌کند.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onDestroy() {
        webView.removeCallbacks(navColorTick)
        super.onDestroy()
    }
}
