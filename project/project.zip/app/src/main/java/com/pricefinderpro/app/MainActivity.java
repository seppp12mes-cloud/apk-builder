package com.pricefinderpro.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends android.app.Activity {
    private static final String PREFS = "pricefinder_settings";
    private static final String KEY_BASE_URL = "base_url";
    private static final String KEY_API_KEY = "api_key";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private EditText searchInput;
    private Button searchButton;
    private ProgressBar progress;
    private LinearLayout resultsContainer;
    private TextView statusText;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        v.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        v.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_START);
        return v;
    }

    private LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return row;
    }

    private TextView pill(String label, int textColor) {
        TextView p = text(label, 12, textColor, true);
        p.setBackgroundResource(com.pricefinderpro.app.R.drawable.bg_pill);
        p.setPadding(dp(8), dp(3), dp(8), dp(3));
        p.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, dp(6), 0);
        p.setLayoutParams(lp);
        return p;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(246, 247, 251));
        root.setPadding(dp(18), dp(12), dp(18), dp(18));

        LinearLayout toolbar = row();
        TextView title = text("PriceFinder PRO", 22, Color.rgb(16,24,40), true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        title.setLayoutParams(titleLp);
        toolbar.addView(title);
        Button settings = new Button(this);
        settings.setText("تنظیمات");
        settings.setAllCaps(false);
        settings.setOnClickListener(v -> showSettings());
        toolbar.addView(settings, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)));
        root.addView(toolbar);

        TextView subtitle = text("قیمت‌ها را از چند Marketplace و فروشنده، ارزان تا گران مقایسه کن.", 13, Color.rgb(102,112,133), false);
        subtitle.setPadding(0, 0, 0, dp(12));
        root.addView(subtitle);

        LinearLayout searchRow = row();
        searchRow.setBackgroundResource(R.drawable.bg_search);
        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setHint("مثلاً PS4 یا آیفون 17 پرو 256 گیگ");
        searchInput.setTextSize(15);
        searchInput.setPadding(0, 0, dp(10), 0);
        searchInput.setInputType(InputType.TYPE_CLASS_TEXT);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, dp(56), 1f);
        searchRow.addView(searchInput, inputLp);
        searchButton = new Button(this);
        searchButton.setText("جستجو");
        searchButton.setAllCaps(false);
        searchButton.setOnClickListener(v -> startSearch());
        searchRow.addView(searchButton, new LinearLayout.LayoutParams(dp(92), dp(56)));
        root.addView(searchRow);

        LinearLayout statusRow = row();
        statusRow.setPadding(0, dp(10), 0, dp(6));
        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        statusRow.addView(progress, new LinearLayout.LayoutParams(dp(28), dp(28)));
        statusText = text("آمادهٔ جستجو", 12, Color.rgb(102,112,133), false);
        statusText.setPadding(dp(8), 0, 0, 0);
        statusRow.addView(statusText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(statusRow);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        resultsContainer = new LinearLayout(this);
        resultsContainer.setOrientation(LinearLayout.VERTICAL);
        resultsContainer.setPadding(0, dp(4), 0, dp(20));
        TextView welcome = text("🔎\n\nیک عبارت وارد کن تا رتبهٔ بهترین فروشگاه، فروشنده‌های ارزان‌تر و همهٔ آفرهای قابل‌تأیید را ببینی.", 16, Color.rgb(52,64,84), false);
        welcome.setGravity(Gravity.CENTER);
        welcome.setPadding(dp(20), dp(80), dp(20), dp(80));
        resultsContainer.addView(welcome);
        scroll.addView(resultsContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        searchInput.requestFocus();
    }

    private String baseUrl() {
        return prefs.getString(KEY_BASE_URL, "").trim().replaceAll("/+$", "");
    }

    private String apiKey() {
        return SecretStore.getApiKey(this).trim();
    }

    private void showSettings() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(8), dp(4), dp(8), 0);

        EditText url = new EditText(this);
        url.setHint("https://your-domain.example");
        url.setSingleLine(true);
        url.setText(baseUrl());
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        form.addView(url);

        EditText key = new EditText(this);
        key.setHint("X-API-Key");
        key.setSingleLine(true);
        key.setText(apiKey());
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        form.addView(key);

        new android.app.AlertDialog.Builder(this)
                .setTitle("اتصال به PriceFinder PRO")
                .setMessage("آدرس Backend و API Key را وارد کن. برای استفادهٔ واقعی HTTPS توصیه می‌شود.")
                .setView(form)
                .setNegativeButton("انصراف", null)
                .setPositiveButton("ذخیره", (dialog, which) -> {
                    String value = url.getText().toString().trim();
                    prefs.edit().putString(KEY_BASE_URL, value).apply();
                    SecretStore.putApiKey(this, key.getText().toString().trim());
                    statusText.setText(value.isEmpty() ? "Backend تنظیم نشده است" : "Backend ذخیره شد");
                }).show();
    }

    private void setLoading(boolean loading) {
        progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        searchButton.setEnabled(!loading);
        searchInput.setEnabled(!loading);
    }

    private void startSearch() {
        String q = searchInput.getText().toString().trim();
        if (q.isEmpty()) {
            Toast.makeText(this, "عبارت جستجو را وارد کن", Toast.LENGTH_SHORT).show();
            return;
        }
        String base = baseUrl();
        if (base.isEmpty()) {
            showSettings();
            Toast.makeText(this, "ابتدا Backend را تنظیم کن", Toast.LENGTH_LONG).show();
            return;
        }

        setLoading(true);
        statusText.setText("در حال جستجوی چندمنبعی…");
        resultsContainer.removeAllViews();
        TextView loading = text("در حال بررسی سایت‌ها، محصولات و آفرهای فروشنده‌ها…", 15, Color.rgb(52,64,84), true);
        loading.setGravity(Gravity.CENTER);
        loading.setPadding(dp(10), dp(70), dp(10), dp(70));
        resultsContainer.addView(loading);

        executor.submit(() -> {
            try {
                String response = callApi(base, q, apiKey());
                JSONObject json = new JSONObject(response);
                runOnUiThread(() -> {
                    setLoading(false);
                    render(json);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setLoading(false);
                    statusText.setText("خطا در دریافت نتیجه");
                    resultsContainer.removeAllViews();
                    TextView error = text("❌ اتصال یا API خطا داد\n\n" + e.getMessage(), 14, Color.rgb(180, 50, 50), true);
                    error.setPadding(dp(14), dp(35), dp(14), dp(35));
                    resultsContainer.addView(error);
                });
            }
        });
    }

    private String callApi(String base, String q, String key) throws Exception {
        String urlString = base + "/api/v18/market-search?q=" + URLEncoder.encode(q, StandardCharsets.UTF_8.name());
        URL url = URI.create(urlString).toURL();
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(90000);
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("Accept-Language", "fa-IR,fa;q=0.9,en;q=0.8");
        connection.setRequestProperty("User-Agent", "PriceFinderPRO-Android/18.0.0");
        if (!key.isEmpty()) connection.setRequestProperty("X-API-Key", key);
        int code = connection.getResponseCode();
        InputStream stream = code >= 200 && code < 400 ? connection.getInputStream() : connection.getErrorStream();
        String body = read(stream);
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + body);
        return body;
    }

    private String read(InputStream stream) throws Exception {
        if (stream == null) return "";
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            StringBuilder out = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) out.append(line);
            return out.toString();
        }
    }

    private View card(LinearLayout content) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(lp);
        if (content != null) card.addView(content);
        return card;
    }

    private void addHeader(String title, String subtitle) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.addView(text(title, 17, Color.rgb(16,24,40), true));
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView t = text(subtitle, 12, Color.rgb(102,112,133), false);
            t.setPadding(0, dp(3), 0, dp(10));
            body.addView(t);
        }
        resultsContainer.addView(card(body));
    }

    private String money(Object value) {
        if (value == null || value == JSONObject.NULL) return "—";
        try {
            double d = Double.parseDouble(String.valueOf(value));
            return String.format(Locale.US, "%,.0f تومان", d);
        } catch (Exception ignored) { return String.valueOf(value); }
    }

    private String str(JSONObject o, String key) { return o.optString(key, ""); }
    private JSONObject obj(JSONObject o, String key) { JSONObject r = o.optJSONObject(key); return r == null ? new JSONObject() : r; }
    private JSONArray arr(JSONObject o, String key) { JSONArray r = o.optJSONArray(key); return r == null ? new JSONArray() : r; }

    private String medal(int rank) {
        if (rank == 1) return "🥇";
        if (rank == 2) return "🥈";
        if (rank == 3) return "🥉";
        return "#" + rank;
    }

    private TextView labelValue(String label, String value, boolean bold) {
        TextView t = text(label + "\n" + value, bold ? 15 : 13, Color.rgb(52,64,84), bold);
        t.setPadding(0, dp(2), 0, dp(2));
        return t;
    }

    private void render(JSONObject data) {
        resultsContainer.removeAllViews();
        String query = str(data, "query");
        int offers = data.optInt("priced_offer_count", 0);
        int exact = data.optInt("exact_offer_count", 0);
        int sellers = data.optInt("seller_count", 0);
        int sites = data.optInt("sites_with_results", 0);
        statusText.setText(String.format(Locale.getDefault(), "%s  •  %d پلتفرم  •  %d آفر دقیق", query, sites, exact));

        LinearLayout summary = new LinearLayout(this);
        summary.setOrientation(LinearLayout.VERTICAL);
        summary.addView(text("نتیجهٔ جستجو: " + query, 19, Color.rgb(16,24,40), true));
        TextView stats = text("پلتفرم: " + sites + "    فروشندهٔ رتبه‌بندی‌شده: " + sellers + "    آفر قیمت‌دار: " + offers + "    EXACT: " + exact, 12, Color.rgb(102,112,133), false);
        stats.setPadding(0, dp(5), 0, 0);
        summary.addView(stats);
        resultsContainer.addView(card(summary));

        renderSites(data);
        renderSellers(data);
        renderOffers(data);
        renderCoverage(data);

        JSONArray errors = arr(data, "errors");
        if (errors.length() > 0) {
            LinearLayout body = new LinearLayout(this);
            body.setOrientation(LinearLayout.VERTICAL);
            body.addView(text("⚠️ برخی منابع محدود/خطادار بودند", 16, Color.rgb(180,83,9), true));
            body.addView(text(errors.length() + " منبع این جستجو را کامل پاسخ ندادند. رتبه‌بندی فقط بر اساس دادهٔ واقعاً استخراج‌شده است.", 12, Color.rgb(102,112,133), false));
            resultsContainer.addView(card(body));
        }
    }

    private void renderSites(JSONObject data) {
        JSONArray sites = arr(data, "site_rankings");
        if (sites.length() == 0) return;
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.addView(text("🏅 بهترین قیمت هر پلتفرم", 17, Color.rgb(16,24,40), true));
        body.addView(text("از هر سایت، ارزان‌ترین آفر دقیق نمایندهٔ رتبهٔ آن سایت است.", 12, Color.rgb(102,112,133), false));
        for (int i=0; i<sites.length(); i++) {
            JSONObject r = sites.optJSONObject(i); if (r == null) continue;
            int rank = r.optInt("rank", i+1);
            LinearLayout item = row();
            TextView m = text(medal(rank), 20, rank<=3?Color.rgb(16,24,40):Color.rgb(102,112,133), true);
            m.setGravity(Gravity.CENTER);
            item.addView(m, new LinearLayout.LayoutParams(dp(48), dp(58)));
            LinearLayout mid = new LinearLayout(this); mid.setOrientation(LinearLayout.VERTICAL);
            mid.addView(text(str(r,"site_name"),15,Color.rgb(16,24,40),true));
            mid.addView(text("فروشنده: " + str(r,"best_seller_name"),12,Color.rgb(102,112,133),false));
            item.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT,1f));
            TextView p = text(money(r.opt("cheapest_price_toman")),14,Color.rgb(6,118,71),true);
            p.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);
            item.addView(p, new LinearLayout.LayoutParams(dp(140), dp(58)));
            body.addView(item);
            if (i < sites.length()-1) addDivider(body);
        }
        resultsContainer.addView(card(body));
    }

    private void renderSellers(JSONObject data) {
        JSONArray sellers = arr(data, "seller_rankings");
        if (sellers.length() == 0) return;
        LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        body.addView(text("🏆 رتبه‌بندی فروشنده‌ها", 17, Color.rgb(16,24,40), true));
        body.addView(text("هر فروشنده یک رتبهٔ مستقل دارد؛ فقط آفرهای EXACT در این بخش وارد می‌شوند.",12,Color.rgb(102,112,133),false));
        int max = Math.min(sellers.length(), 25);
        for (int i=0;i<max;i++) {
            JSONObject r=sellers.optJSONObject(i); if(r==null)continue;
            int rank=r.optInt("rank",i+1);
            LinearLayout item=row();
            item.setPadding(0,dp(9),0,dp(9));
            item.addView(text(medal(rank),20,Color.rgb(16,24,40),true), new LinearLayout.LayoutParams(dp(48),dp(70)));
            LinearLayout mid=new LinearLayout(this); mid.setOrientation(LinearLayout.VERTICAL);
            mid.addView(text(str(r,"site_name")+" • "+str(r,"seller_name"),14,Color.rgb(16,24,40),true));
            JSONObject best=obj(r,"best_offer");
            mid.addView(text(str(best,"title"),11,Color.rgb(102,112,133),false));
            item.addView(mid,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));
            item.addView(text(money(r.opt("cheapest_price_toman")),14,Color.rgb(6,118,71),true),new LinearLayout.LayoutParams(dp(140),dp(70)));
            body.addView(item);
            Button open = new Button(this); open.setText("مشاهده آفر"); open.setAllCaps(false);
            String url=str(best,"url"); open.setOnClickListener(v->openUrl(url));
            body.addView(open,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(44)));
            if(i<max-1)addDivider(body);
        }
        resultsContainer.addView(card(body));
    }

    private void renderOffers(JSONObject data) {
        JSONArray offers = arr(data, "offers");
        if (offers.length() == 0) return;
        LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        body.addView(text("💰 همهٔ آفرها از ارزان به گران",17,Color.rgb(16,24,40),true));
        body.addView(text("آفرهای UNVERIFIED برای شفافیت نمایش داده می‌شوند، اما رتبه نمی‌گیرند.",12,Color.rgb(102,112,133),false));
        int max = Math.min(offers.length(), 60);
        for (int i=0;i<max;i++) {
            JSONObject o=offers.optJSONObject(i); if(o==null)continue;
            int rank=o.optInt("global_rank",i+1); boolean exact=o.optBoolean("exact_match",false);
            LinearLayout item=row(); item.setPadding(0,dp(8),0,dp(8));
            item.addView(text("#"+rank,12,Color.rgb(102,112,133),true),new LinearLayout.LayoutParams(dp(44),dp(82)));
            LinearLayout mid=new LinearLayout(this); mid.setOrientation(LinearLayout.VERTICAL);
            mid.addView(text(str(o,"site_name"),13,Color.rgb(16,24,40),true));
            mid.addView(text(str(o,"seller_name").isEmpty()?"فروشنده نامشخص":str(o,"seller_name"),12,Color.rgb(102,112,133),false));
            mid.addView(text(str(o,"title"),11,Color.rgb(152,162,179),false));
            item.addView(mid,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));
            LinearLayout right=new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL); right.setGravity(Gravity.END);
            right.addView(text(money(o.opt("price_toman")),13,Color.rgb(6,118,71),true));
            right.addView(pill(exact?"EXACT 100%":"UNVERIFIED", exact?Color.rgb(6,118,71):Color.rgb(180,83,9)));
            item.addView(right,new LinearLayout.LayoutParams(dp(145),dp(82)));
            body.addView(item);
            Button open=new Button(this); open.setText("باز کردن فروشگاه"); open.setAllCaps(false); String url=str(o,"url"); open.setOnClickListener(v->openUrl(url)); body.addView(open,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(42)));
            if(i<max-1)addDivider(body);
        }
        resultsContainer.addView(card(body));
    }

    private void renderCoverage(JSONObject data) {
        JSONArray discovery=arr(data,"discovery");
        if(discovery.length()==0)return;
        LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        body.addView(text("🛰️ پوشش کشف Marketplace",17,Color.rgb(16,24,40),true));
        body.addView(text("این عدد نشان می‌دهد استخراج هر منبع چقدر موفق بوده؛ partial به معنی محدودیت همان سایت است، نه خطای کل سیستم.",12,Color.rgb(102,112,133),false));
        for(int i=0;i<discovery.length();i++){
            JSONObject r=discovery.optJSONObject(i); if(r==null)continue;
            String line=str(r,"site_name")+"  •  آفر: "+r.optInt("unique_offers",0)+"  •  فروشنده: "+r.optInt("unique_sellers",0)+"  •  پوشش: "+String.format(Locale.US,"%.0f%%",r.optDouble("completeness_score",0));
            body.addView(text(line,12,Color.rgb(52,64,84),true));
            body.addView(text(r.optBoolean("partial",false)?"⚠️ partial":"✅ complete-attempt",11,r.optBoolean("partial",false)?Color.rgb(180,83,9):Color.rgb(6,118,71),false));
            if(i<discovery.length()-1)addDivider(body);
        }
        resultsContainer.addView(card(body));
    }

    private void addDivider(LinearLayout parent) {
        View divider=new View(this); divider.setBackgroundColor(Color.rgb(234,236,240)); parent.addView(divider,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(1)));
    }

    private void openUrl(String url) {
        if(url==null || url.isEmpty())return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch(Exception e){Toast.makeText(this,"باز کردن لینک ممکن نشد",Toast.LENGTH_SHORT).show();}
    }

    @Override protected void onDestroy(){ super.onDestroy(); executor.shutdownNow(); }
}
