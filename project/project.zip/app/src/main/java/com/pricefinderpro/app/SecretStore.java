package com.pricefinderpro.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.util.Base64;

final class SecretStore {
    private static final String KS = "AndroidKeyStore";
    private static final String ALIAS = "PriceFinderProApiKey";
    private static final String PREF = "pricefinder_secrets";

    private SecretStore() {}

    static void putApiKey(Context context, String value) {
        try {
            if (value == null || value.isEmpty()) {
                context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove("api_key").apply();
                return;
            }
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getKey());
            byte[] ciphertext = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
            byte[] payload = new byte[cipher.getIV().length + ciphertext.length];
            System.arraycopy(cipher.getIV(), 0, payload, 0, cipher.getIV().length);
            System.arraycopy(ciphertext, 0, payload, cipher.getIV().length, ciphertext.length);
            context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                    .putString("api_key", Base64.encodeToString(payload, Base64.NO_WRAP)).apply();
        } catch (Exception e) {
            // API key is optional; failing secure storage should not crash the app.
            context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove("api_key").apply();
        }
    }

    static String getApiKey(Context context) {
        String encoded = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("api_key", "");
        if (encoded.isEmpty()) return "";
        try {
            byte[] payload = Base64.decode(encoded, Base64.NO_WRAP);
            int ivLength = 12;
            byte[] iv = new byte[ivLength];
            byte[] ciphertext = new byte[payload.length - ivLength];
            System.arraycopy(payload, 0, iv, 0, ivLength);
            System.arraycopy(payload, ivLength, ciphertext, 0, ciphertext.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(ciphertext), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private static SecretKey getKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(KS);
        keyStore.load(null);
        if (keyStore.containsAlias(ALIAS)) {
            return ((KeyStore.SecretKeyEntry) keyStore.getEntry(ALIAS, null)).getSecretKey();
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KS);
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return generator.generateKey();
    }
}
