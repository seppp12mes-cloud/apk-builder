/*
 * ReelDrop — اپ دانلود ویدیو اینستاگرام (Jetpack Compose، فقط یک فایل)
 *
 * این فایل را بدون هیچ تغییری در اپ‌ساز (حالت «یک فایل») قرار بده؛ Compose، Coroutines، مانیفست،
 * مجوز اینترنت و ترافیک http همه خودکار اضافه می‌شوند (نسخه‌ی اصلاح‌شده‌ی اپ‌ساز لازم است).
 *
 *  - اپ بدون کامپیوتر و مستقیم روی گوشی کار می‌کند. سرور server.py فقط یک راه پشتیبان اختیاری است
 *    برای وقتی که اینستاگرام اجازه‌ی خواندن مستقیم نمی‌دهد.
 *  - سرور server.py (همان که قبلاً ساختیم) باید روشن باشد.
 *      شبیه‌ساز:   http://10.0.2.2:8000
 *      گوشی واقعی: HOST=0.0.0.0 python server.py   و آدرس IP کامپیوتر، مثلاً http://192.168.1.20:8000
 *    آدرس سرور را داخل اپ از آیکن تنظیمات (بالا سمت چپ) عوض کن.
 */
package com.reeldrop.app

import android.content.ContentValues
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/* ───────────── رنگ‌ها و تم ───────────── */

private val Ink = Color(0xFF0A0916)
private val Ink2 = Color(0xFF14122A)
private val Violet = Color(0xFF8B5CFF)
private val Pink = Color(0xFFFF3D8B)
private val Cyan = Color(0xFF22D3EE)
private val Amber = Color(0xFFFFB86B)
private val Mint = Color(0xFF34D399)
private val Glass = Color(0x14FFFFFF)
private val GlassLine = Color(0x26FFFFFF)
private val NeonLoop = listOf(Cyan, Violet, Pink, Amber, Cyan)

// خالی = اپ مستقیم از خود گوشی کار می‌کند؛ سرور فقط یک راه پشتیبان اختیاری است.
private const val DEFAULT_SERVER = ""

@Composable
private fun ReelDropTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Pink, background = Ink, surface = Ink2, onSurface = Color.White),
        content = content
    )
}

/* ───────────── مدل و شبکه ───────────── */

private data class VideoInfo(
    val title: String,
    val uploader: String,
    val duration: Int,
    val thumbUrl: String?,
    val videoUrl: String? = null // اگر پر باشد، ویدیو مستقیم از همین آدرس و بدون سرور دانلود می‌شود
)

private sealed interface Phase {
    object Idle : Phase
    object Loading : Phase
    class Ready(val info: VideoInfo, val thumb: ImageBitmap?) : Phase
    class Failed(val message: String) : Phase
}

private val IG_REGEX = Regex("^https?://(www\\.)?instagram\\.com/(p|reel|reels|tv)/[\\w-]+", RegexOption.IGNORE_CASE)

private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

private fun clean(s: String?): String = if (s == null || s == "null") "" else s

private fun metaContent(html: String, prop: String): String? {
    val p = Regex.escape(prop)
    val a = Regex("<meta[^>]*?(?:property|name)=[\"']" + p + "[\"'][^>]*?content=[\"']([^\"']*)[\"']", RegexOption.IGNORE_CASE)
    val b = Regex("<meta[^>]*?content=[\"']([^\"']*)[\"'][^>]*?(?:property|name)=[\"']" + p + "[\"']", RegexOption.IGNORE_CASE)
    val v = a.find(html)?.groupValues?.get(1) ?: b.find(html)?.groupValues?.get(1)
    return v?.replace("&amp;", "&")?.replace("&quot;", "\"")?.replace("&#039;", "'")?.replace("&#x2F;", "/")
        ?.takeIf { it.isNotBlank() }
}

/** تلاش مستقیم از خود گوشی: صفحه‌ی عمومی پست را می‌خواند و آدرس ویدیو را از متای آن برمی‌دارد. */
private fun fetchDirect(link: String): VideoInfo {
    val c = URL(link).openConnection() as HttpURLConnection
    c.connectTimeout = 10_000
    c.readTimeout = 20_000
    c.setRequestProperty("User-Agent", "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)")
    c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
    try {
        val html = c.inputStream.bufferedReader().use { it.readText() }
        val video = metaContent(html, "og:video") ?: metaContent(html, "og:video:secure_url")
            ?: throw IllegalStateException("no video")
        return VideoInfo(
            title = (metaContent(html, "og:title") ?: "").take(140),
            uploader = "",
            duration = 0,
            thumbUrl = metaContent(html, "og:image"),
            videoUrl = video
        )
    } finally {
        c.disconnect()
    }
}

private suspend fun fetchInfo(base: String, link: String): VideoInfo = withContext(Dispatchers.IO) {
    val direct = runCatching { fetchDirect(link) }.getOrNull()
    if (direct != null) return@withContext direct
    if (base.isBlank()) {
        throw IllegalStateException(
            "ویدیو پیدا نشد. فقط پست‌های عمومی پشتیبانی می‌شوند و گاهی اینستاگرام اجازه‌ی دسترسی نمی‌دهد. " +
                "می‌توانی در تنظیمات آدرس یک سرور را هم وارد کنی."
        )
    }
    fetchFromServer(base, link)
}

private suspend fun fetchFromServer(base: String, link: String): VideoInfo = withContext(Dispatchers.IO) {
    val c = URL("$base/api/info?url=${enc(link)}").openConnection() as HttpURLConnection
    c.connectTimeout = 10_000
    c.readTimeout = 60_000
    try {
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        val j = JSONObject(body)
        if (code !in 200..299) throw IllegalStateException(clean(j.optString("error")).ifBlank { "خطای ناشناخته از سرور" })
        VideoInfo(
            title = clean(j.optString("title")),
            uploader = clean(j.optString("uploader")),
            duration = j.optInt("duration", 0),
            thumbUrl = clean(j.optString("thumbnail")).ifBlank { null }
        )
    } finally {
        c.disconnect()
    }
}

private suspend fun fetchThumb(url: String): ImageBitmap? = withContext(Dispatchers.IO) {
    try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8_000
        c.readTimeout = 15_000
        c.inputStream.use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
    } catch (e: Exception) {
        null
    }
}

/** ویدیو را از سرور می‌گیرد و در Movies/ReelDrop ذخیره می‌کند. onProgress: 0..1 یا -1 اگر حجم معلوم نیست. */
private suspend fun downloadToGallery(ctx: Context, source: String, onProgress: (Float) -> Unit) =
    withContext(Dispatchers.IO) {
        val c = URL(source).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
        c.connectTimeout = 10_000
        c.readTimeout = 180_000
        val resolver = ctx.contentResolver
        var created: Uri? = null
        try {
            val code = c.responseCode
            if (code !in 200..299) {
                val body = c.errorStream?.bufferedReader()?.use { it.readText() } ?: "{}"
                throw IllegalStateException(clean(runCatching { JSONObject(body).optString("error") }.getOrNull()).ifBlank { "دانلود ناموفق بود" })
            }
            val total = c.contentLengthLong
            val fileName = "ReelDrop_${System.currentTimeMillis()}.mp4"
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ReelDrop")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val target = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("ساخت فایل در گالری ممکن نشد")
                created = target
                c.inputStream.use { input ->
                    resolver.openOutputStream(target)!!.use { out -> copyWithProgress(input, out, total, onProgress) }
                }
                resolver.update(target, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            } else {
                // اندروید ۸ و ۹: داخل پوشه‌ی اختصاصی اپ (Android/data/.../files/Movies) ذخیره می‌شود
                val dir = ctx.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES) ?: ctx.filesDir
                val file = java.io.File(dir, fileName)
                try {
                    c.inputStream.use { input -> file.outputStream().use { out -> copyWithProgress(input, out, total, onProgress) } }
                } catch (e: Exception) {
                    file.delete()
                    throw e
                }
            }
        } catch (e: Exception) {
            created?.let { runCatching { resolver.delete(it, null, null) } }
            throw e
        } finally {
            c.disconnect()
        }
    }

private fun kotlinx.coroutines.CoroutineScope.copyWithProgress(
    input: java.io.InputStream, out: java.io.OutputStream, total: Long, onProgress: (Float) -> Unit
) {
    val buf = ByteArray(64 * 1024)
    var done = 0L
    while (true) {
        ensureActive()
        val n = input.read(buf)
        if (n < 0) break
        out.write(buf, 0, n)
        done += n
        onProgress(if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else -1f)
    }
}

private fun friendly(e: Exception): String = when (e) {
    is java.net.ConnectException, is java.net.UnknownHostException, is java.net.SocketTimeoutException ->
        "اتصال برقرار نشد. اینترنت (و VPN) گوشی را بررسی کن. اگر سرور وارد کرده‌ای، آدرسش را در تنظیمات چک کن."
    else -> e.message?.takeIf { it.isNotBlank() } ?: "خطای ناشناخته"
}

/* ───────────── اکتیویتی ───────────── */

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            ReelDropTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    ReelDropApp()
                }
            }
        }
    }
}

/* ───────────── صفحه‌ی اصلی ───────────── */

@Composable
private fun ReelDropApp() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val prefs = remember { ctx.getSharedPreferences("reeldrop", Context.MODE_PRIVATE) }

    var server by remember { mutableStateOf(prefs.getString("server", DEFAULT_SERVER) ?: DEFAULT_SERVER) }
    var link by remember { mutableStateOf("") }
    var phase by remember { mutableStateOf<Phase>(Phase.Idle) }
    var dlState by remember { mutableStateOf(0) } // 0 آماده، 1 در حال ذخیره، 2 تمام
    var dlProgress by remember { mutableStateOf(0f) }
    var showSettings by remember { mutableStateOf(false) }

    fun fetch() {
        val l = link.trim()
        if (!IG_REGEX.containsMatchIn(l)) {
            phase = Phase.Failed("لینک معتبر پست، ریلز یا IGTV اینستاگرام وارد کن.")
            return
        }
        phase = Phase.Loading
        dlState = 0
        scope.launch {
            phase = try {
                val info = fetchInfo(server, l)
                val thumb = info.thumbUrl?.let { fetchThumb(it) }
                Phase.Ready(info, thumb)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Phase.Failed(friendly(e))
            }
        }
    }

    fun download() {
        val direct = (phase as? Phase.Ready)?.info?.videoUrl
        if (direct == null && server.isBlank()) {
            Toast.makeText(ctx, "آدرس ویدیو پیدا نشد. دوباره «دریافت ویدیو» را بزن.", Toast.LENGTH_LONG).show()
            return
        }
        val source = direct ?: "$server/api/download?url=${enc(link.trim())}"
        dlState = 1
        dlProgress = 0f
        scope.launch {
            try {
                downloadToGallery(ctx, source) { dlProgress = it }
                dlState = 2
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                dlState = 0
                Toast.makeText(ctx, friendly(e), Toast.LENGTH_LONG).show()
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground()
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Glass)
                        .border(1.dp, GlassLine, CircleShape)
                        .clickable { showSettings = true },
                    contentAlignment = Alignment.Center
                ) { SettingsIcon() }
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LogoMark()
                Wordmark()
            }
            Spacer(Modifier.height(6.dp))
            CyclingText(
                listOf("ریل‌های دلخواهت، یک ضربه تا گالری", "لینک رو بچسبون، بقیه‌اش با من", "سریع، تمیز و بدون دردسر"),
                color = Color.White.copy(alpha = 0.7f), size = 14
            )
            Spacer(Modifier.height(28.dp))

            GlowSearchBar(
                value = link,
                onValue = { link = it },
                onPaste = { clipboard.getText()?.text?.let { link = it.trim() } },
                onGo = { fetch() }
            )
            Spacer(Modifier.height(14.dp))
            GradientButton("دریافت ویدیو", onClick = { fetch() }, enabled = phase !is Phase.Loading, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(26.dp))

            AnimatedContent(
                targetState = phase,
                contentKey = { it::class },
                transitionSpec = {
                    (fadeIn(tween(450)) + scaleIn(initialScale = 0.92f, animationSpec = tween(450))) togetherWith fadeOut(tween(200))
                },
                label = "phase"
            ) { p ->
                when (p) {
                    Phase.Idle -> HowItWorks()
                    Phase.Loading -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        OrbitLoader()
                        Spacer(Modifier.height(12.dp))
                        CyclingText(listOf("در حال پیدا کردن ویدیو…", "دارم لینک رو باز می‌کنم…", "چند لحظه‌ی دیگه آماده‌ست…"))
                    }
                    is Phase.Failed -> ErrorCard(p.message)
                    is Phase.Ready -> ResultCard(p.info, p.thumb, dlState, dlProgress) { download() }
                }
            }
            Spacer(Modifier.height(28.dp))
            Text(
                "فقط ویدیوهای خودت یا ویدیوهایی که اجازه‌ی دانلودشان را داری.",
                color = Color.White.copy(alpha = 0.4f), fontSize = 11.sp, textAlign = TextAlign.Center
            )
        }
    }

    if (showSettings) {
        var draft by remember { mutableStateOf(server) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            containerColor = Color(0xFF191636),
            title = { Text("سرور پشتیبان (اختیاری)", color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "اگر خالی بماند، اپ مستقیم از خود گوشی کار می‌کند. فقط اگر پست‌ها پیدا نشدند، آدرس سرور خودت را بنویس، مثل http://192.168.1.20:8000",
                        color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp
                    )
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Ink2)
                            .border(1.dp, GlassLine, RoundedCornerShape(14.dp))
                            .padding(14.dp)
                    ) { PlainField(draft, { draft = it }, "http://...") }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    server = draft.trim().trimEnd('/').ifBlank { DEFAULT_SERVER }
                    prefs.edit().putString("server", server).apply()
                    showSettings = false
                }) { Text("ذخیره", color = Cyan, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("بستن", color = Color.White.copy(alpha = 0.6f)) } }
        )
    }
}

/* ───────────── پس‌زمینه‌ی شفق متحرک ───────────── */

@Composable
private fun AuroraBackground() {
    val t = rememberInfiniteTransition(label = "aurora")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(16_000, easing = LinearEasing)), label = "p")
    Canvas(Modifier.fillMaxSize().background(Ink)) {
        val a = p * 2f * PI.toFloat()
        val w = size.width
        val h = size.height
        fun blob(color: Color, cx: Float, cy: Float, r: Float) {
            drawCircle(
                Brush.radialGradient(listOf(color.copy(alpha = 0.5f), Color.Transparent), center = Offset(cx, cy), radius = r),
                radius = r, center = Offset(cx, cy)
            )
        }
        blob(Violet, w * (0.2f + 0.18f * sin(a)), h * (0.16f + 0.08f * cos(a)), w * 0.95f)
        blob(Pink, w * (0.85f + 0.12f * cos(a)), h * (0.42f + 0.1f * sin(a)), w * 0.8f)
        blob(Cyan, w * (0.3f + 0.2f * cos(a * 1f + 1f)), h * (0.85f + 0.06f * sin(a)), w * 0.85f)
        // ذره‌های درخشان که به آرامی بالا می‌روند
        for (i in 0 until 28) {
            val baseX = ((i * 37) % 100) / 100f
            val baseY = ((i * 61) % 100) / 100f
            val speed = 0.25f + (i % 5) * 0.06f
            val y = (((baseY - p * speed) % 1f) + 1f) % 1f
            val alpha = 0.12f + 0.4f * abs(sin(a * (1 + i % 3) + i))
            drawCircle(Color.White.copy(alpha = alpha), radius = (1.2f + (i % 3)) * density, center = Offset(baseX * w, y * h))
        }
    }
}

/* ───────────── لوگو و نام اپ ───────────── */

@Composable
private fun LogoMark(size: Dp = 54.dp) {
    val t = rememberInfiniteTransition(label = "logo")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(5_000, easing = LinearEasing)), label = "rot")
    val bounce by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1_000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        val c = Offset(s / 2, s / 2)
        drawCircle(Brush.radialGradient(listOf(Pink.copy(alpha = 0.45f), Color.Transparent), c, s * 0.62f), radius = s * 0.62f, center = c)
        rotate(rot, pivot = c) { drawCircle(Brush.sweepGradient(NeonLoop, c), radius = s / 2, center = c) }
        drawCircle(Ink, radius = s / 2 - s * 0.075f, center = c)
        val off = bounce * s * 0.07f
        val stroke = Stroke(width = s * 0.07f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        val stem = Path().apply { moveTo(c.x, s * 0.26f + off); lineTo(c.x, s * 0.58f + off) }
        val head = Path().apply {
            moveTo(c.x - s * 0.13f, s * 0.46f + off); lineTo(c.x, s * 0.6f + off); lineTo(c.x + s * 0.13f, s * 0.46f + off)
        }
        val tray = Path().apply { moveTo(c.x - s * 0.17f, s * 0.74f); lineTo(c.x + s * 0.17f, s * 0.74f) }
        drawPath(stem, Color.White, style = stroke)
        drawPath(head, Color.White, style = stroke)
        drawPath(tray, Cyan, style = stroke)
    }
}

@Composable
private fun Wordmark() {
    val t = rememberInfiniteTransition(label = "wm")
    val shift by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3_200, easing = LinearEasing)), label = "s")
    val w = 700f
    val brush = Brush.linearGradient(
        colors = NeonLoop,
        start = Offset(shift * w - w, 0f),
        end = Offset(shift * w, 0f),
        tileMode = TileMode.Repeated
    )
    Text(
        "ReelDrop",
        style = TextStyle(brush = brush, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp)
    )
}

@Composable
private fun CyclingText(lines: List<String>, color: Color = Color.White.copy(alpha = 0.8f), size: Int = 15) {
    var i by remember { mutableStateOf(0) }
    LaunchedEffect(lines) {
        while (true) {
            delay(1_900)
            i = (i + 1) % lines.size
        }
    }
    AnimatedContent(
        targetState = i,
        transitionSpec = {
            (fadeIn(tween(350)) + slideInVertically { it / 2 }) togetherWith (fadeOut(tween(250)) + slideOutVertically { -it / 2 })
        },
        label = "cycle"
    ) { idx -> Text(lines[idx], color = color, fontSize = size.sp, textAlign = TextAlign.Center) }
}

/* ───────────── جستجو و دکمه ───────────── */

@Composable
private fun PlainField(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    imeAction: ImeAction = ImeAction.Default,
    onGo: () -> Unit = {}
) {
    BasicTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = 15.sp, textDirection = TextDirection.Ltr),
        cursorBrush = SolidColor(Cyan),
        keyboardOptions = KeyboardOptions(imeAction = imeAction, keyboardType = KeyboardType.Uri),
        keyboardActions = KeyboardActions(onGo = { onGo() }),
        modifier = modifier,
        decorationBox = { inner ->
            Box(contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty()) Text(placeholder, color = Color.White.copy(alpha = 0.4f), fontSize = 14.sp)
                inner()
            }
        }
    )
}

@Composable
private fun GlowSearchBar(value: String, onValue: (String) -> Unit, onPaste: () -> Unit, onGo: () -> Unit) {
    val t = rememberInfiniteTransition(label = "bar")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(4_200, easing = LinearEasing)), label = "r")
    Box(
        Modifier
            .fillMaxWidth()
            .height(66.dp)
            .clip(RoundedCornerShape(33.dp))
            .drawBehind { rotate(rot) { drawCircle(Brush.sweepGradient(NeonLoop), radius = size.maxDimension) } }
            .padding(2.dp)
            .clip(RoundedCornerShape(31.dp))
            .background(Ink2)
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MagnifierIcon()
            PlainField(
                value, onValue, "لینک ریل یا پست را بچسبان",
                modifier = Modifier.weight(1f), imeAction = ImeAction.Go, onGo = onGo
            )
            Box(
                Modifier
                    .clip(CircleShape)
                    .background(Cyan.copy(alpha = 0.14f))
                    .clickable { onPaste() }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) { Text("چسباندن", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun GradientButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val t = rememberInfiniteTransition(label = "btn")
    val sh by t.animateFloat(-0.3f, 1.3f, infiniteRepeatable(tween(2_200, easing = LinearEasing)), label = "sh")
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.95f else 1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "sc")
    Box(
        modifier
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .alpha(if (enabled) 1f else 0.5f)
            .clip(CircleShape)
            .background(Brush.horizontalGradient(listOf(Violet, Pink, Amber)))
            .drawWithContent {
                drawContent()
                val x = size.width * sh
                drawRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.38f), Color.Transparent),
                        startX = x - size.width * 0.18f, endX = x + size.width * 0.18f
                    )
                )
            }
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
            .padding(vertical = 17.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold) }
}

/* ───────────── لودینگ مداری ───────────── */

@Composable
private fun OrbitLoader() {
    val t = rememberInfiniteTransition(label = "orbit")
    val a by t.animateFloat(0f, 360f, infiniteRepeatable(tween(2_200, easing = LinearEasing)), label = "a")
    val b by t.animateFloat(360f, 0f, infiniteRepeatable(tween(3_600, easing = LinearEasing)), label = "b")
    val pulse by t.animateFloat(0.85f, 1.15f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    Canvas(Modifier.size(150.dp)) {
        val c = center
        val r = size.minDimension / 2
        val sw = 6.dp.toPx()
        drawCircle(Brush.radialGradient(listOf(Pink.copy(alpha = 0.5f), Color.Transparent), c, r * 0.6f * pulse), radius = r * 0.6f * pulse, center = c)
        rotate(a, pivot = c) {
            drawArc(
                Brush.sweepGradient(listOf(Color.Transparent, Cyan, Violet), c),
                startAngle = 0f, sweepAngle = 280f, useCenter = false,
                topLeft = Offset(c.x - r * 0.92f, c.y - r * 0.92f), size = Size(r * 1.84f, r * 1.84f),
                style = Stroke(sw, cap = StrokeCap.Round)
            )
        }
        rotate(b, pivot = c) {
            drawArc(
                Brush.sweepGradient(listOf(Color.Transparent, Amber, Pink), c),
                startAngle = 0f, sweepAngle = 220f, useCenter = false,
                topLeft = Offset(c.x - r * 0.68f, c.y - r * 0.68f), size = Size(r * 1.36f, r * 1.36f),
                style = Stroke(sw * 0.7f, cap = StrokeCap.Round)
            )
        }
        for (i in 0 until 3) {
            val ang = (a * 1.5f + i * 120f) * PI.toFloat() / 180f
            drawCircle(
                Color.White, radius = 4.dp.toPx(),
                center = Offset(c.x + cos(ang) * r * 0.46f, c.y + sin(ang) * r * 0.46f)
            )
        }
        val s = r * 0.26f * pulse
        val tri = Path().apply {
            moveTo(c.x - s * 0.5f, c.y - s * 0.7f); lineTo(c.x + s * 0.8f, c.y); lineTo(c.x - s * 0.5f, c.y + s * 0.7f); close()
        }
        drawPath(tri, Color.White)
    }
}

/* ───────────── کارت‌ها ───────────── */

@Composable
private fun HowItWorks() {
    val steps = listOf(
        "در اینستاگرام روی «ارسال» بزن و «کپی لینک» را انتخاب کن",
        "لینک را بالا بچسبان و «دریافت ویدیو» را بزن",
        "ویدیو مستقیم داخل گالری ذخیره می‌شود"
    )
    val digits = listOf("۱", "۲", "۳")
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Glass)
            .border(1.dp, GlassLine, RoundedCornerShape(26.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        steps.forEachIndexed { i, s ->
            val a = remember { Animatable(0f) }
            LaunchedEffect(Unit) { delay(180L * i); a.animateTo(1f, tween(550)) }
            Row(
                Modifier.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 36f },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    Modifier.size(34.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Violet, Pink))),
                    contentAlignment = Alignment.Center
                ) { Text(digits[i], color = Color.White, fontWeight = FontWeight.ExtraBold) }
                Text(s, color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ErrorCard(message: String) {
    val shake = remember { Animatable(0f) }
    LaunchedEffect(message) {
        repeat(3) { shake.animateTo(10f, tween(50)); shake.animateTo(-10f, tween(50)) }
        shake.animateTo(0f, tween(50))
    }
    Column(
        Modifier
            .offset { IntOffset(shake.value.roundToInt(), 0) }
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(Pink.copy(alpha = 0.12f))
            .border(1.dp, Pink.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("اوه، مشکلی پیش اومد", color = Pink, fontWeight = FontWeight.ExtraBold)
        Text(message, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
    }
}

@Composable
private fun ResultCard(info: VideoInfo, thumb: ImageBitmap?, state: Int, progress: Float, onDownload: () -> Unit) {
    val t = rememberInfiniteTransition(label = "card")
    val tilt by t.animateFloat(-2f, 2f, infiniteRepeatable(tween(3_000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "tilt")
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Glass)
            .border(1.dp, GlassLine, RoundedCornerShape(28.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
                Modifier
                    .width(104.dp)
                    .aspectRatio(9f / 16f)
                    .graphicsLayer { rotationZ = tilt }
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.linearGradient(listOf(Violet, Pink))),
                contentAlignment = Alignment.Center
            ) {
                if (thumb != null) {
                    Image(thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                } else {
                    Canvas(Modifier.size(30.dp)) {
                        drawPath(
                            Path().apply { moveTo(size.width * 0.2f, 0f); lineTo(size.width, size.height / 2); lineTo(size.width * 0.2f, size.height); close() },
                            Color.White
                        )
                    }
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    info.title.ifBlank { "ویدیو اینستاگرام" },
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 4, overflow = TextOverflow.Ellipsis
                )
                if (info.uploader.isNotBlank()) Text("@" + info.uploader, color = Cyan, fontSize = 13.sp)
                if (info.duration > 0) {
                    Box(Modifier.clip(CircleShape).background(Amber.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                        Text("%d:%02d".format(info.duration / 60, info.duration % 60), color = Amber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        when (state) {
            0 -> GradientButton("ذخیره در گالری", onClick = onDownload, modifier = Modifier.fillMaxWidth())
            1 -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ProgressBar(progress)
                Text(
                    if (progress >= 0) "در حال ذخیره… ${(progress * 100).toInt()}٪" else "در حال ذخیره…",
                    color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp, modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
            else -> DoneBanner(onAgain = onDownload)
        }
    }
}

@Composable
private fun ProgressBar(progress: Float) {
    val t = rememberInfiniteTransition(label = "pb")
    val sweep by t.animateFloat(-0.3f, 1.3f, infiniteRepeatable(tween(1_300, easing = LinearEasing)), label = "sw")
    val shown by animateFloatAsState(progress, tween(250), label = "prog")
    Canvas(Modifier.fillMaxWidth().height(14.dp).clip(CircleShape).background(Glass)) {
        val brush = Brush.horizontalGradient(listOf(Cyan, Violet, Pink))
        if (progress < 0f) {
            val segW = size.width * 0.3f
            drawRoundRect(brush, topLeft = Offset(size.width * sweep - segW / 2, 0f), size = Size(segW, size.height), cornerRadius = CornerRadius(size.height / 2))
        } else {
            drawRoundRect(brush, size = Size(size.width * shown.coerceIn(0.02f, 1f), size.height), cornerRadius = CornerRadius(size.height / 2))
        }
    }
}

@Composable
private fun DoneBanner(onAgain: () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val s by animateFloatAsState(if (shown) 1f else 0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "done")
    Row(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = s; scaleY = s }
            .clip(RoundedCornerShape(20.dp))
            .background(Mint.copy(alpha = 0.14f))
            .border(1.dp, Mint.copy(alpha = 0.45f), RoundedCornerShape(20.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Canvas(Modifier.size(34.dp)) {
            drawCircle(Mint)
            val p = Path().apply {
                moveTo(size.width * 0.28f, size.height * 0.52f)
                lineTo(size.width * 0.44f, size.height * 0.68f)
                lineTo(size.width * 0.74f, size.height * 0.34f)
            }
            drawPath(p, Ink, style = Stroke(size.width * 0.1f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        Column(Modifier.weight(1f)) {
            Text("ذخیره شد!", color = Mint, fontWeight = FontWeight.ExtraBold)
            Text("پوشه‌ی Movies › ReelDrop در گالری", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
        }
        Text("دوباره", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onAgain() }.padding(8.dp))
    }
}

/* ───────────── آیکن‌های رسم‌شده ───────────── */

@Composable
private fun MagnifierIcon() {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width
        val sw = w * 0.11f
        drawCircle(Cyan, radius = w * 0.32f, center = Offset(w * 0.42f, w * 0.42f), style = Stroke(sw))
        drawLine(Cyan, Offset(w * 0.66f, w * 0.66f), Offset(w * 0.92f, w * 0.92f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}

@Composable
private fun SettingsIcon() {
    Canvas(Modifier.size(20.dp)) {
        val w = size.width
        val sw = w * 0.09f
        for ((i, k) in listOf(0.25f, 0.5f, 0.75f).withIndex()) {
            val y = w * k
            drawLine(Color.White.copy(alpha = 0.8f), Offset(0f, y), Offset(w, y), strokeWidth = sw, cap = StrokeCap.Round)
            drawCircle(if (i == 1) Pink else Cyan, radius = w * 0.1f, center = Offset(w * (0.3f + 0.2f * i), y))
        }
    }
}
