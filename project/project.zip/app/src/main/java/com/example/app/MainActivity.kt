package com.example.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.*
import android.widget.ProgressBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var hadError = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val progress = findViewById<ProgressBar>(R.id.progress)
        val offline = findViewById<View>(R.id.offline)
        webView = findViewById(R.id.webview)
        val swipe = findViewById<SwipeRefreshLayout>(R.id.swipe)
        swipe.setOnRefreshListener { webView.reload() }

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        webView.settings.loadWithOverviewMode = true
        webView.settings.useWideViewPort = true

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme ?: ""
                if (scheme == "http" || scheme == "https") {
                    return false
                }
                if (scheme == "about" || scheme == "javascript" || scheme == "data" || scheme == "blob" || scheme == "file") {
                    return false
                }
                try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (e: Exception) {}
                return true
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                hadError = false
            }

            override fun onPageFinished(view: WebView, url: String) {
                // onPageFinished is also called after an error, so the offline screen must not be hidden then.
                if (!hadError) {
                    offline.visibility = View.GONE
                    webView.visibility = View.VISIBLE
                }
                swipe.isRefreshing = false
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                if (!request.isForMainFrame) return
                val code = error.errorCode
                if (code == WebViewClient.ERROR_HOST_LOOKUP ||
                    code == WebViewClient.ERROR_CONNECT ||
                    code == WebViewClient.ERROR_TIMEOUT ||
                    code == WebViewClient.ERROR_IO
                ) {
                    hadError = true
                    webView.visibility = View.GONE
                    offline.visibility = View.VISIBLE
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
        }

        findViewById<View>(R.id.retry).setOnClickListener {
            offline.visibility = View.GONE
            webView.reload()
        }

        webView.loadUrl("https://cshope.ir/")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
